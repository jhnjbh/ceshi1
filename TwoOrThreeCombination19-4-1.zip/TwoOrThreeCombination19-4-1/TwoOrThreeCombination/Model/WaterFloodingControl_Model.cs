﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwoOrThreeCombination.Model
{
    public class WaterFloodingControl_Model
    {
        string waterflood_id,

            blockname,
            oilarea,
            wellspacing,
            underground,
            density,
            air,
            recoveryrate,
            watertype,
            sandbody,
            scenarioname,
            implement,
            groudliang;

        public string Air
        {
            get
            {
                return air;
            }

            set
            {
                air = value;
            }
        }

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Density
        {
            get
            {
                return density;
            }

            set
            {
                density = value;
            }
        }

        public string Groudliang
        {
            get
            {
                return groudliang;
            }

            set
            {
                groudliang = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Oilarea
        {
            get
            {
                return oilarea;
            }

            set
            {
                oilarea = value;
            }
        }

        public string Recoveryrate
        {
            get
            {
                return recoveryrate;
            }

            set
            {
                recoveryrate = value;
            }
        }

        public string Sandbody
        {
            get
            {
                return sandbody;
            }

            set
            {
                sandbody = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Underground
        {
            get
            {
                return underground;
            }

            set
            {
                underground = value;
            }
        }

        public string Waterflood_id
        {
            get
            {
                return waterflood_id;
            }

            set
            {
                waterflood_id = value;
            }
        }

        public string Watertype
        {
            get
            {
                return watertype;
            }

            set
            {
                watertype = value;
            }
        }

        public string Wellspacing
        {
            get
            {
                return wellspacing;
            }

            set
            {
                wellspacing = value;
            }
        }
    }

}