﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwoOrThreeCombination.Model
{
    public class EconomicEvalution_Model
    {

    }
    //基础数据
    public class EcoBasics_Model
    {
        string basics_id,

            blockname,
            units,
            oilname,
            consstartyear,
            operstartyear,
            costcoe,
            constime,
            runtime,
            newoilcapa,
            commodityoil,
            commoditynatural,
            oilprice,

            scenarioname,
            implement;

        public string Basics_id
        {
            get
            {
                return basics_id;
            }

            set
            {
                basics_id = value;
            }
        }

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Commoditynatural
        {
            get
            {
                return commoditynatural;
            }

            set
            {
                commoditynatural = value;
            }
        }

        public string Commodityoil
        {
            get
            {
                return commodityoil;
            }

            set
            {
                commodityoil = value;
            }
        }

        public string Consstartyear
        {
            get
            {
                return consstartyear;
            }

            set
            {
                consstartyear = value;
            }
        }

        public string Constime
        {
            get
            {
                return constime;
            }

            set
            {
                constime = value;
            }
        }

        public string Costcoe
        {
            get
            {
                return costcoe;
            }

            set
            {
                costcoe = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Newoilcapa
        {
            get
            {
                return newoilcapa;
            }

            set
            {
                newoilcapa = value;
            }
        }

        public string Oilname
        {
            get
            {
                return oilname;
            }

            set
            {
                oilname = value;
            }
        }

        public string Oilprice
        {
            get
            {
                return oilprice;
            }

            set
            {
                oilprice = value;
            }
        }

        public string Operstartyear
        {
            get
            {
                return operstartyear;
            }

            set
            {
                operstartyear = value;
            }
        }

        public string Runtime
        {
            get
            {
                return runtime;
            }

            set
            {
                runtime = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Units
        {
            get
            {
                return units;
            }

            set
            {
                units = value;
            }
        }
    }

    //现状数据
    public class EcoActuality_Model
    {
        string actuality_id,

            blockname,
            oilwell,
            materials,
            actwork,
            direct,
            waterwells,
            fuel,
            test,
            factmines,
            oilmass,
            powers,
            repair,
            liquidmea,
            personnel,
            recoverys,
            watermass,
            injection,
            oilmanage,
            airflow,
            therecovery,
            transport,

            scenarioname,
            implement,
            allmoney;

        public string Actuality_id
        {
            get
            {
                return actuality_id;
            }

            set
            {
                actuality_id = value;
            }
        }

        public string Actwork
        {
            get
            {
                return actwork;
            }

            set
            {
                actwork = value;
            }
        }

        public string Airflow
        {
            get
            {
                return airflow;
            }

            set
            {
                airflow = value;
            }
        }

        public string Allmoney
        {
            get
            {
                return allmoney;
            }

            set
            {
                allmoney = value;
            }
        }

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Direct
        {
            get
            {
                return direct;
            }

            set
            {
                direct = value;
            }
        }

        public string Factmines
        {
            get
            {
                return factmines;
            }

            set
            {
                factmines = value;
            }
        }

        public string Fuel
        {
            get
            {
                return fuel;
            }

            set
            {
                fuel = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Injection
        {
            get
            {
                return injection;
            }

            set
            {
                injection = value;
            }
        }

        public string Liquidmea
        {
            get
            {
                return liquidmea;
            }

            set
            {
                liquidmea = value;
            }
        }

        public string Materials
        {
            get
            {
                return materials;
            }

            set
            {
                materials = value;
            }
        }

        public string Oilmanage
        {
            get
            {
                return oilmanage;
            }

            set
            {
                oilmanage = value;
            }
        }

        public string Oilmass
        {
            get
            {
                return oilmass;
            }

            set
            {
                oilmass = value;
            }
        }

        public string Oilwell
        {
            get
            {
                return oilwell;
            }

            set
            {
                oilwell = value;
            }
        }

        public string Personnel
        {
            get
            {
                return personnel;
            }

            set
            {
                personnel = value;
            }
        }

        public string Powers
        {
            get
            {
                return powers;
            }

            set
            {
                powers = value;
            }
        }

        public string Recoverys
        {
            get
            {
                return recoverys;
            }

            set
            {
                recoverys = value;
            }
        }

        public string Repair
        {
            get
            {
                return repair;
            }

            set
            {
                repair = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Test
        {
            get
            {
                return test;
            }

            set
            {
                test = value;
            }
        }

        public string Therecovery
        {
            get
            {
                return therecovery;
            }

            set
            {
                therecovery = value;
            }
        }

        public string Transport
        {
            get
            {
                return transport;
            }

            set
            {
                transport = value;
            }
        }

        public string Watermass
        {
            get
            {
                return watermass;
            }

            set
            {
                watermass = value;
            }
        }

        public string Waterwells
        {
            get
            {
                return waterwells;
            }

            set
            {
                waterwells = value;
            }
        }
    }
    //无项目
    public class EcoNoproject_Model
    {
        string noproject_id,

        blockname,
        nominaltime,
        oilformula,
        fluid,
        water,

        scenarioname,
        implement,
        formula_a,
        formula_b;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Fluid
        {
            get
            {
                return fluid;
            }

            set
            {
                fluid = value;
            }
        }

        public string Formula_a
        {
            get
            {
                return formula_a;
            }

            set
            {
                formula_a = value;
            }
        }

        public string Formula_b
        {
            get
            {
                return formula_b;
            }

            set
            {
                formula_b = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Nominaltime
        {
            get
            {
                return nominaltime;
            }

            set
            {
                nominaltime = value;
            }
        }

        public string Noproject_id
        {
            get
            {
                return noproject_id;
            }

            set
            {
                noproject_id = value;
            }
        }

        public string Oilformula
        {
            get
            {
                return oilformula;
            }

            set
            {
                oilformula = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Water
        {
            get
            {
                return water;
            }

            set
            {
                water = value;
            }
        }
    }
    //有项目
    public class EcoYesproject_Model
    {
        string yesproject_id,

        blockname,
        nominaltime,
        newformula,
        theretime,

        scenarioname,
        implement,
        formula_a,
        formula_b;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Formula_a
        {
            get
            {
                return formula_a;
            }

            set
            {
                formula_a = value;
            }
        }

        public string Formula_b
        {
            get
            {
                return formula_b;
            }

            set
            {
                formula_b = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Newformula
        {
            get
            {
                return newformula;
            }

            set
            {
                newformula = value;
            }
        }

        public string Nominaltime
        {
            get
            {
                return nominaltime;
            }

            set
            {
                nominaltime = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Theretime
        {
            get
            {
                return theretime;
            }

            set
            {
                theretime = value;
            }
        }

        public string Yesproject_id
        {
            get
            {
                return yesproject_id;
            }

            set
            {
                yesproject_id = value;
            }
        }
    }
    //新钻开发井投资
    public class EcoWellinvest_Model
    {
        string wellinvest_id,

        blockname,
        years,
        model,
        mark,
        unitprice,

        scenarioname,
        implement;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Mark
        {
            get
            {
                return mark;
            }

            set
            {
                mark = value;
            }
        }

        public string Model
        {
            get
            {
                return model;
            }

            set
            {
                model = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Unitprice
        {
            get
            {
                return unitprice;
            }

            set
            {
                unitprice = value;
            }
        }

        public string Wellinvest_id
        {
            get
            {
                return wellinvest_id;
            }

            set
            {
                wellinvest_id = value;
            }
        }

        public string Years
        {
            get
            {
                return years;
            }

            set
            {
                years = value;
            }
        }
    }
    //新钻配套地面投资
    public class EcoGroinvest_Model
    {
        string groinvest_id,

        blockname,
        years,
        model,
        mark,
        unitprice,

        scenarioname,
        implement;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Groinvest_id
        {
            get
            {
                return groinvest_id;
            }

            set
            {
                groinvest_id = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Mark
        {
            get
            {
                return mark;
            }

            set
            {
                mark = value;
            }
        }

        public string Model
        {
            get
            {
                return model;
            }

            set
            {
                model = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Unitprice
        {
            get
            {
                return unitprice;
            }

            set
            {
                unitprice = value;
            }
        }

        public string Years
        {
            get
            {
                return years;
            }

            set
            {
                years = value;
            }
        }
    }
    //老井治理费用
    public class EcoOldgovern_Model
    {
        string oldgovern_id,

        blockname,
        years,
        model,
        measure,
        mark,
        unitprice,

        scenarioname,
        implement;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Mark
        {
            get
            {
                return mark;
            }

            set
            {
                mark = value;
            }
        }

        public string Measure
        {
            get
            {
                return measure;
            }

            set
            {
                measure = value;
            }
        }

        public string Model
        {
            get
            {
                return model;
            }

            set
            {
                model = value;
            }
        }

        public string Oldgovern_id
        {
            get
            {
                return oldgovern_id;
            }

            set
            {
                oldgovern_id = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Unitprice
        {
            get
            {
                return unitprice;
            }

            set
            {
                unitprice = value;
            }
        }

        public string Years
        {
            get
            {
                return years;
            }

            set
            {
                years = value;
            }
        }
    }
    //老井弃置费用
    public class EcoOldgiveup_Model
    {
        string oldgiveup_id,

        blockname,
        years,
        giveuptype,
        mark,
        unitprice,

        scenarioname,
        implement;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Giveuptype
        {
            get
            {
                return giveuptype;
            }

            set
            {
                giveuptype = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Mark
        {
            get
            {
                return mark;
            }

            set
            {
                mark = value;
            }
        }

        public string Oldgiveup_id
        {
            get
            {
                return oldgiveup_id;
            }

            set
            {
                oldgiveup_id = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Unitprice
        {
            get
            {
                return unitprice;
            }

            set
            {
                unitprice = value;
            }
        }

        public string Years
        {
            get
            {
                return years;
            }

            set
            {
                years = value;
            }
        }
    }
    //地面改造投资
    public class EcoGround_Model
    {
        string ground_id,

        blockname,
        years,
        groundtype,
        stationname,
        modelnum,
        lengths,
        wellmodel,
        manner,
        unitprice,

        scenarioname,
        implement;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Groundtype
        {
            get
            {
                return groundtype;
            }

            set
            {
                groundtype = value;
            }
        }

        public string Ground_id
        {
            get
            {
                return ground_id;
            }

            set
            {
                ground_id = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Lengths
        {
            get
            {
                return lengths;
            }

            set
            {
                lengths = value;
            }
        }

        public string Manner
        {
            get
            {
                return manner;
            }

            set
            {
                manner = value;
            }
        }

        public string Modelnum
        {
            get
            {
                return modelnum;
            }

            set
            {
                modelnum = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Stationname
        {
            get
            {
                return stationname;
            }

            set
            {
                stationname = value;
            }
        }

        public string Unitprice
        {
            get
            {
                return unitprice;
            }

            set
            {
                unitprice = value;
            }
        }

        public string Wellmodel
        {
            get
            {
                return wellmodel;
            }

            set
            {
                wellmodel = value;
            }
        }

        public string Years
        {
            get
            {
                return years;
            }

            set
            {
                years = value;
            }
        }
    }
    //重大攻关研究
    public class EecoTacklepoint_Model
    {
        string tacklepoint_id,

        blockname,
        years,
        unitprice,

        scenarioname,
        implement;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Tacklepoint_id
        {
            get
            {
                return tacklepoint_id;
            }

            set
            {
                tacklepoint_id = value;
            }
        }

        public string Unitprice
        {
            get
            {
                return unitprice;
            }

            set
            {
                unitprice = value;
            }
        }

        public string Years
        {
            get
            {
                return years;
            }

            set
            {
                years = value;
            }
        }
    }
    //前期基础研究
    public class EcoEarlier_Model
    {
        string earlier_id,

        blockname,
        years,
        unitprice,

        scenarioname,
        implement;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Earlier_id
        {
            get
            {
                return earlier_id;
            }

            set
            {
                earlier_id = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Unitprice
        {
            get
            {
                return unitprice;
            }

            set
            {
                unitprice = value;
            }
        }

        public string Years
        {
            get
            {
                return years;
            }

            set
            {
                years = value;
            }
        }
    }
    //药剂费
    public class EcoPotion_Model
    {
        string potion_id,

        blockname,
        years,
        potiontype,
        potionnum,
        unitprice,

        scenarioname,
        implement,
        addprice;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Potionnum
        {
            get
            {
                return potionnum;
            }

            set
            {
                potionnum = value;
            }
        }

        public string Potiontype
        {
            get
            {
                return potiontype;
            }

            set
            {
                potiontype = value;
            }
        }

        public string Potion_id
        {
            get
            {
                return potion_id;
            }

            set
            {
                potion_id = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Unitprice
        {
            get
            {
                return unitprice;
            }

            set
            {
                unitprice = value;
            }
        }

        public string Years
        {
            get
            {
                return years;
            }

            set
            {
                years = value;
            }
        }
        public string Addprice
        {
            get
            {
                return addprice;
            }

            set
            {
                addprice = value;
            }
        }
    }
    //成本估算
    public class EcoCostest_Model
    {
        string costest_id,

        blockname,
        costesttype,
        noproject,
        yesproject,
        remark,

        scenarioname,
        implement,
        estimate;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Costesttype
        {
            get
            {
                return costesttype;
            }

            set
            {
                costesttype = value;
            }
        }

        public string Costest_id
        {
            get
            {
                return costest_id;
            }

            set
            {
                costest_id = value;
            }
        }

        public string Estimate
        {
            get
            {
                return estimate;
            }

            set
            {
                estimate = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Noproject
        {
            get
            {
                return noproject;
            }

            set
            {
                noproject = value;
            }
        }

        public string Remark
        {
            get
            {
                return remark;
            }

            set
            {
                remark = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Yesproject
        {
            get
            {
                return yesproject;
            }

            set
            {
                yesproject = value;
            }
        }
    }
    //成本估算加年
    public class EcoCostestY_Model
    {
        string ycostest_id,

        blockname,
        ycostesttype,
        ynoproject,
        yyesproject,
        yremark,

        scenarioname,
        implement,
        yestimate,
        yyear;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Ycostesttype
        {
            get
            {
                return ycostesttype;
            }

            set
            {
                ycostesttype = value;
            }
        }

        public string Ycostest_id
        {
            get
            {
                return ycostest_id;
            }

            set
            {
                ycostest_id = value;
            }
        }

        public string Yestimate
        {
            get
            {
                return yestimate;
            }

            set
            {
                yestimate = value;
            }
        }

        public string Ynoproject
        {
            get
            {
                return ynoproject;
            }

            set
            {
                ynoproject = value;
            }
        }

        public string Yremark
        {
            get
            {
                return yremark;
            }

            set
            {
                yremark = value;
            }
        }

        public string Yyear
        {
            get
            {
                return yyear;
            }

            set
            {
                yyear = value;
            }
        }

        public string Yyesproject
        {
            get
            {
                return yyesproject;
            }

            set
            {
                yyesproject = value;
            }
        }
    }
    //查询区块名称
    public class EcoBlockname_Model
    {
        string name_block;

        public string Name_block
        {
            get
            {
                return name_block;
            }

            set
            {
                name_block = value;
            }
        }
    }
    //查询方案名称
    public class EcoScenario_name_Model
    {
        string scenario_name;

        public string Scenario_name
        {
            get
            {
                return scenario_name;
            }

            set
            {
                scenario_name = value;
            }
        }
    }
    //15年计算
    public class EcoYearfifteen_Model
    {
        string yearone,
            yeartwo,
            yearthere,
            yearfore,
            yearfive,
            yearsix,
            yearseven,
            yeareight,
            yearnine,
            yearten,
            yeareleven,
            yeartwelve,
            yearthirteen,
            yearfourteen,
            yearfifteen;

        public string Yeareight
        {
            get
            {
                return yeareight;
            }

            set
            {
                yeareight = value;
            }
        }

        public string Yeareleven
        {
            get
            {
                return yeareleven;
            }

            set
            {
                yeareleven = value;
            }
        }

        public string Yearfifteen
        {
            get
            {
                return yearfifteen;
            }

            set
            {
                yearfifteen = value;
            }
        }

        public string Yearfive
        {
            get
            {
                return yearfive;
            }

            set
            {
                yearfive = value;
            }
        }

        public string Yearfore
        {
            get
            {
                return yearfore;
            }

            set
            {
                yearfore = value;
            }
        }

        public string Yearfourteen
        {
            get
            {
                return yearfourteen;
            }

            set
            {
                yearfourteen = value;
            }
        }

        public string Yearnine
        {
            get
            {
                return yearnine;
            }

            set
            {
                yearnine = value;
            }
        }

        public string Yearone
        {
            get
            {
                return yearone;
            }

            set
            {
                yearone = value;
            }
        }

        public string Yearseven
        {
            get
            {
                return yearseven;
            }

            set
            {
                yearseven = value;
            }
        }

        public string Yearsix
        {
            get
            {
                return yearsix;
            }

            set
            {
                yearsix = value;
            }
        }

        public string Yearten
        {
            get
            {
                return yearten;
            }

            set
            {
                yearten = value;
            }
        }

        public string Yearthere
        {
            get
            {
                return yearthere;
            }

            set
            {
                yearthere = value;
            }
        }

        public string Yearthirteen
        {
            get
            {
                return yearthirteen;
            }

            set
            {
                yearthirteen = value;
            }
        }

        public string Yeartwelve
        {
            get
            {
                return yeartwelve;
            }

            set
            {
                yeartwelve = value;
            }
        }

        public string Yeartwo
        {
            get
            {
                return yeartwo;
            }

            set
            {
                yeartwo = value;
            }
        }

    }
    public class EcoYearRecovery_Model
    {
        string increase;

        public string Increase
        {
            get
            {
                return increase;
            }

            set
            {
                increase = value;
            }
        }
    }
    public class EcoNewwell_Model//这个是新井数据字段
    {
        //newwell_id,
        string yesproject_id,//有项目ID  
            stime,
            oilshu,
            oilchan,
            oilye,
            watershu,
            waterzhu;

        //public string Newwell_id
        //{
        //    get
        //    {
        //        return newwell_id;
        //    }

        //    set
        //    {
        //        newwell_id = value;
        //    }
        //}

        public string Oilchan
        {
            get
            {
                return oilchan;
            }

            set
            {
                oilchan = value;
            }
        }

        public string Oilshu
        {
            get
            {
                return oilshu;
            }

            set
            {
                oilshu = value;
            }
        }

        public string Oilye
        {
            get
            {
                return oilye;
            }

            set
            {
                oilye = value;
            }
        }

        public string Stime
        {
            get
            {
                return stime;
            }

            set
            {
                stime = value;
            }
        }

        public string Watershu
        {
            get
            {
                return watershu;
            }

            set
            {
                watershu = value;
            }
        }

        public string Waterzhu
        {
            get
            {
                return waterzhu;
            }

            set
            {
                waterzhu = value;
            }
        }

        public string Yesproject_id
        {
            get
            {
                return yesproject_id;
            }

            set
            {
                yesproject_id = value;
            }
        }
    }
    public class EcoNfifteenEnd_Model
    {
        string nid,
            nonee,
            ntwo,
            nthree,
            nfour,
            nfive,
            nsix,
            nseven,
            neight,
            nnine,
            nten,
            neleven,
            ntwelve,
            nthirteen,
            nfourteen,
            nfifteen;

        public string Neight
        {
            get
            {
                return neight;
            }

            set
            {
                neight = value;
            }
        }

        public string Neleven
        {
            get
            {
                return neleven;
            }

            set
            {
                neleven = value;
            }
        }

        public string Nfifteen
        {
            get
            {
                return nfifteen;
            }

            set
            {
                nfifteen = value;
            }
        }

        public string Nfive
        {
            get
            {
                return nfive;
            }

            set
            {
                nfive = value;
            }
        }

        public string Nfour
        {
            get
            {
                return nfour;
            }

            set
            {
                nfour = value;
            }
        }

        public string Nfourteen
        {
            get
            {
                return nfourteen;
            }

            set
            {
                nfourteen = value;
            }
        }

        public string Nid
        {
            get
            {
                return nid;
            }

            set
            {
                nid = value;
            }
        }

        public string Nnine
        {
            get
            {
                return nnine;
            }

            set
            {
                nnine = value;
            }
        }

        public string Nonee
        {
            get
            {
                return nonee;
            }

            set
            {
                nonee = value;
            }
        }

        public string Nseven
        {
            get
            {
                return nseven;
            }

            set
            {
                nseven = value;
            }
        }

        public string Nsix
        {
            get
            {
                return nsix;
            }

            set
            {
                nsix = value;
            }
        }

        public string Nten
        {
            get
            {
                return nten;
            }

            set
            {
                nten = value;
            }
        }

        public string Nthirteen
        {
            get
            {
                return nthirteen;
            }

            set
            {
                nthirteen = value;
            }
        }

        public string Nthree
        {
            get
            {
                return nthree;
            }

            set
            {
                nthree = value;
            }
        }

        public string Ntwelve
        {
            get
            {
                return ntwelve;
            }

            set
            {
                ntwelve = value;
            }
        }

        public string Ntwo
        {
            get
            {
                return ntwo;
            }

            set
            {
                ntwo = value;
            }
        }
    }
    public class EcoYfifteenEnd_Model
    {
        string yid,
            yonee,
            ytwo,
            ythree,
            yfour,
            yfive,
            ysix,
            yseven,
            yeight,
            ynine,
            yten,
            yeleven,
            ytwelve,
            ythirteen,
            yfourteen,
            yfifteen;

        public string Yeight
        {
            get
            {
                return yeight;
            }

            set
            {
                yeight = value;
            }
        }

        public string Yeleven
        {
            get
            {
                return yeleven;
            }

            set
            {
                yeleven = value;
            }
        }

        public string Yfifteen
        {
            get
            {
                return yfifteen;
            }

            set
            {
                yfifteen = value;
            }
        }

        public string Yfive
        {
            get
            {
                return yfive;
            }

            set
            {
                yfive = value;
            }
        }

        public string Yfour
        {
            get
            {
                return yfour;
            }

            set
            {
                yfour = value;
            }
        }

        public string Yfourteen
        {
            get
            {
                return yfourteen;
            }

            set
            {
                yfourteen = value;
            }
        }

        public string Yid
        {
            get
            {
                return yid;
            }

            set
            {
                yid = value;
            }
        }

        public string Ynine
        {
            get
            {
                return ynine;
            }

            set
            {
                ynine = value;
            }
        }

        public string Yonee
        {
            get
            {
                return yonee;
            }

            set
            {
                yonee = value;
            }
        }

        public string Yseven
        {
            get
            {
                return yseven;
            }

            set
            {
                yseven = value;
            }
        }

        public string Ysix
        {
            get
            {
                return ysix;
            }

            set
            {
                ysix = value;
            }
        }

        public string Yten
        {
            get
            {
                return yten;
            }

            set
            {
                yten = value;
            }
        }

        public string Ythirteen
        {
            get
            {
                return ythirteen;
            }

            set
            {
                ythirteen = value;
            }
        }

        public string Ythree
        {
            get
            {
                return ythree;
            }

            set
            {
                ythree = value;
            }
        }

        public string Ytwelve
        {
            get
            {
                return ytwelve;
            }

            set
            {
                ytwelve = value;
            }
        }

        public string Ytwo
        {
            get
            {
                return ytwo;
            }

            set
            {
                ytwo = value;
            }
        }
    }

    public class selNoproOilall_Model
    {
        string nid,
        nonee,
        ntwo,
        nthree,
        nfour,
        nfive,
        nsix,
        nseven,
        neight,
        nnine,
        nten,
        neleven,
        ntwelve,
        nthirteen,
        nfourteen,
        nfifteen,
        scenarioname;

        public string Neight
        {
            get
            {
                return neight;
            }

            set
            {
                neight = value;
            }
        }

        public string Neleven
        {
            get
            {
                return neleven;
            }

            set
            {
                neleven = value;
            }
        }

        public string Nfifteen
        {
            get
            {
                return nfifteen;
            }

            set
            {
                nfifteen = value;
            }
        }

        public string Nfive
        {
            get
            {
                return nfive;
            }

            set
            {
                nfive = value;
            }
        }

        public string Nfour
        {
            get
            {
                return nfour;
            }

            set
            {
                nfour = value;
            }
        }

        public string Nfourteen
        {
            get
            {
                return nfourteen;
            }

            set
            {
                nfourteen = value;
            }
        }

        public string Nid
        {
            get
            {
                return nid;
            }

            set
            {
                nid = value;
            }
        }

        public string Nnine
        {
            get
            {
                return nnine;
            }

            set
            {
                nnine = value;
            }
        }

        public string Nonee
        {
            get
            {
                return nonee;
            }

            set
            {
                nonee = value;
            }
        }

        public string Nseven
        {
            get
            {
                return nseven;
            }

            set
            {
                nseven = value;
            }
        }

        public string Nsix
        {
            get
            {
                return nsix;
            }

            set
            {
                nsix = value;
            }
        }

        public string Nten
        {
            get
            {
                return nten;
            }

            set
            {
                nten = value;
            }
        }

        public string Nthirteen
        {
            get
            {
                return nthirteen;
            }

            set
            {
                nthirteen = value;
            }
        }

        public string Nthree
        {
            get
            {
                return nthree;
            }

            set
            {
                nthree = value;
            }
        }

        public string Ntwelve
        {
            get
            {
                return ntwelve;
            }

            set
            {
                ntwelve = value;
            }
        }

        public string Ntwo
        {
            get
            {
                return ntwo;
            }

            set
            {
                ntwo = value;
            }
        }

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }
    }

    public class selYesproOilall_Model
    {
        string yid,
            yonee,
            ytwo,
            ythree,
            yfour,
            yfive,
            ysix,
            yseven,
            yeight,
            ynine,
            yten,
            yeleven,
            ytwelve,
            ythirteen,
            yfourteen,
            yfifteen,
            scenarioname;

        public string Scenarioname
        {
            get
            {
                return scenarioname;
            }

            set
            {
                scenarioname = value;
            }
        }

        public string Yeight
        {
            get
            {
                return yeight;
            }

            set
            {
                yeight = value;
            }
        }

        public string Yeleven
        {
            get
            {
                return yeleven;
            }

            set
            {
                yeleven = value;
            }
        }

        public string Yfifteen
        {
            get
            {
                return yfifteen;
            }

            set
            {
                yfifteen = value;
            }
        }

        public string Yfive
        {
            get
            {
                return yfive;
            }

            set
            {
                yfive = value;
            }
        }

        public string Yfour
        {
            get
            {
                return yfour;
            }

            set
            {
                yfour = value;
            }
        }

        public string Yfourteen
        {
            get
            {
                return yfourteen;
            }

            set
            {
                yfourteen = value;
            }
        }

        public string Yid
        {
            get
            {
                return yid;
            }

            set
            {
                yid = value;
            }
        }

        public string Ynine
        {
            get
            {
                return ynine;
            }

            set
            {
                ynine = value;
            }
        }

        public string Yonee
        {
            get
            {
                return yonee;
            }

            set
            {
                yonee = value;
            }
        }

        public string Yseven
        {
            get
            {
                return yseven;
            }

            set
            {
                yseven = value;
            }
        }

        public string Ysix
        {
            get
            {
                return ysix;
            }

            set
            {
                ysix = value;
            }
        }

        public string Yten
        {
            get
            {
                return yten;
            }

            set
            {
                yten = value;
            }
        }

        public string Ythirteen
        {
            get
            {
                return ythirteen;
            }

            set
            {
                ythirteen = value;
            }
        }

        public string Ythree
        {
            get
            {
                return ythree;
            }

            set
            {
                ythree = value;
            }
        }

        public string Ytwelve
        {
            get
            {
                return ytwelve;
            }

            set
            {
                ytwelve = value;
            }
        }

        public string Ytwo
        {
            get
            {
                return ytwo;
            }

            set
            {
                ytwo = value;
            }
        }
    }
    public class ChooseScenarioname_Model
    {
        string scenario_name;

        public string Scenario_name
        {
            get
            {
                return scenario_name;
            }

            set
            {
                scenario_name = value;
            }
        }
    }
}

