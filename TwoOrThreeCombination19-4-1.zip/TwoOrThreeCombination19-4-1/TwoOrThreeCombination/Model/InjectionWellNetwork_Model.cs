﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//注采井网技术优选Model
namespace TwoOrThreeCombination.Model
{
    public class InjectionWellNetwork_Model
    {
        string injection_id, name_block, scenario_name, oil_bearing, well_pattern, well_spacing,
            crude_viscosity, well_density, air_infiltration, displacing_medium, recoveryrate, choosebool, implement, geological;

        public string Air_infiltration
        {
            get
            {
                return air_infiltration;
            }

            set
            {
                air_infiltration = value;
            }
        }

        public string Choosebool
        {
            get
            {
                return choosebool;
            }

            set
            {
                choosebool = value;
            }
        }

        public string Crude_viscosity
        {
            get
            {
                return crude_viscosity;
            }

            set
            {
                crude_viscosity = value;
            }
        }

        public string Displacing_medium
        {
            get
            {
                return displacing_medium;
            }

            set
            {
                displacing_medium = value;
            }
        }

        public string Geological
        {
            get
            {
                return geological;
            }

            set
            {
                geological = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Injection_id
        {
            get
            {
                return injection_id;
            }

            set
            {
                injection_id = value;
            }
        }

        public string Name_block
        {
            get
            {
                return name_block;
            }

            set
            {
                name_block = value;
            }
        }

        public string Oil_bearing
        {
            get
            {
                return oil_bearing;
            }

            set
            {
                oil_bearing = value;
            }
        }

        public string Recoveryrate
        {
            get
            {
                return recoveryrate;
            }

            set
            {
                recoveryrate = value;
            }
        }

        public string Scenario_name
        {
            get
            {
                return scenario_name;
            }

            set
            {
                scenario_name = value;
            }
        }

        public string Well_density
        {
            get
            {
                return well_density;
            }

            set
            {
                well_density = value;
            }
        }

        public string Well_pattern
        {
            get
            {
                return well_pattern;
            }

            set
            {
                well_pattern = value;
            }
        }

        public string Well_spacing
        {
            get
            {
                return well_spacing;
            }

            set
            {
                well_spacing = value;
            }
        }
    }
    public class InjectionDisplace_Model
    {
        string injection_id, name_block,program_allname, displace, oil_bearing, well_pattern, well_spacing,
            crude_viscosity, well_density, air_infiltration, displacing_medium, recoveryrate, choosebool, implement, geological, scenario_name;

        public string Air_infiltration
        {
            get
            {
                return air_infiltration;
            }

            set
            {
                air_infiltration = value;
            }
        }

        public string Choosebool
        {
            get
            {
                return choosebool;
            }

            set
            {
                choosebool = value;
            }
        }

        public string Crude_viscosity
        {
            get
            {
                return crude_viscosity;
            }

            set
            {
                crude_viscosity = value;
            }
        }

        public string Displace
        {
            get
            {
                return displace;
            }

            set
            {
                displace = value;
            }
        }

        public string Displacing_medium
        {
            get
            {
                return displacing_medium;
            }

            set
            {
                displacing_medium = value;
            }
        }

        public string Geological
        {
            get
            {
                return geological;
            }

            set
            {
                geological = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Injection_id
        {
            get
            {
                return injection_id;
            }

            set
            {
                injection_id = value;
            }
        }

        public string Name_block
        {
            get
            {
                return name_block;
            }

            set
            {
                name_block = value;
            }
        }

        public string Oil_bearing
        {
            get
            {
                return oil_bearing;
            }

            set
            {
                oil_bearing = value;
            }
        }

        public string Program_allname
        {
            get
            {
                return program_allname;
            }

            set
            {
                program_allname = value;
            }
        }

        public string Recoveryrate
        {
            get
            {
                return recoveryrate;
            }

            set
            {
                recoveryrate = value;
            }
        }

        public string Scenario_name
        {
            get
            {
                return scenario_name;
            }

            set
            {
                scenario_name = value;
            }
        }

        public string Well_density
        {
            get
            {
                return well_density;
            }

            set
            {
                well_density = value;
            }
        }

        public string Well_pattern
        {
            get
            {
                return well_pattern;
            }

            set
            {
                well_pattern = value;
            }
        }

        public string Well_spacing
        {
            get
            {
                return well_spacing;
            }

            set
            {
                well_spacing = value;
            }
        }
    }
    public class InjectionWellScenario_Model
    {
        string scenario_name;

        public string Scenario_name
        {
            get
            {
                return scenario_name;
            }

            set
            {
                scenario_name = value;
            }
        }
    }
    public class InjectionWellNetAll_Model
    {
        string injection_id, name_block, scenario_name, oil_bearing, well_pattern, well_spacing,
    crude_viscosity, well_density, air_infiltration, displacing_medium, wellnet_relation;

        public string Air_infiltration
        {
            get
            {
                return air_infiltration;
            }

            set
            {
                air_infiltration = value;
            }
        }

        public string Crude_viscosity
        {
            get
            {
                return crude_viscosity;
            }

            set
            {
                crude_viscosity = value;
            }
        }

        public string Displacing_medium
        {
            get
            {
                return displacing_medium;
            }

            set
            {
                displacing_medium = value;
            }
        }

        public string Injection_id
        {
            get
            {
                return injection_id;
            }

            set
            {
                injection_id = value;
            }
        }

        public string Name_block
        {
            get
            {
                return name_block;
            }

            set
            {
                name_block = value;
            }
        }

        public string Oil_bearing
        {
            get
            {
                return oil_bearing;
            }

            set
            {
                oil_bearing = value;
            }
        }

        public string Scenario_name
        {
            get
            {
                return scenario_name;
            }

            set
            {
                scenario_name = value;
            }
        }

        public string Wellnet_relation
        {
            get
            {
                return wellnet_relation;
            }

            set
            {
                wellnet_relation = value;
            }
        }

        public string Well_density
        {
            get
            {
                return well_density;
            }

            set
            {
                well_density = value;
            }
        }

        public string Well_pattern
        {
            get
            {
                return well_pattern;
            }

            set
            {
                well_pattern = value;
            }
        }

        public string Well_spacing
        {
            get
            {
                return well_spacing;
            }

            set
            {
                well_spacing = value;
            }
        }
    }

    public class InjectionWellProg_Model
    {
        string progname;

        public string Progname
        {
            get
            {
                return progname;
            }

            set
            {
                progname = value;
            }
        }
    }

    public class InjectionChooseNum_Model
    {
        string num;

        public string Num
        {
            get
            {
                return num;
            }

            set
            {
                num = value;
            }
        }
    }


}