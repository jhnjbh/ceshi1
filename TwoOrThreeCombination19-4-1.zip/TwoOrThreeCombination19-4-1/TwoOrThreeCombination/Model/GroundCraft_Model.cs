﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwoOrThreeCombination.Model
{
    public class GroundCraft_Model
    {
        string ground_id,
            name_block,
            online,
            scattered,
            single,
            pump,
            target,
            water,
            aeraone,
            aeratwo,
            singlea,
            wings,
            screw;

        public string Aeraone
        {
            get
            {
                return aeraone;
            }

            set
            {
                aeraone = value;
            }
        }

        public string Aeratwo
        {
            get
            {
                return aeratwo;
            }

            set
            {
                aeratwo = value;
            }
        }

        public string Ground_id
        {
            get
            {
                return ground_id;
            }

            set
            {
                ground_id = value;
            }
        }

        public string Name_block
        {
            get
            {
                return name_block;
            }

            set
            {
                name_block = value;
            }
        }

        public string Online
        {
            get
            {
                return online;
            }

            set
            {
                online = value;
            }
        }

        public string Pump
        {
            get
            {
                return pump;
            }

            set
            {
                pump = value;
            }
        }

        public string Scattered
        {
            get
            {
                return scattered;
            }

            set
            {
                scattered = value;
            }
        }

        public string Screw
        {
            get
            {
                return screw;
            }

            set
            {
                screw = value;
            }
        }

        public string Single
        {
            get
            {
                return single;
            }

            set
            {
                single = value;
            }
        }

        public string Singlea
        {
            get
            {
                return singlea;
            }

            set
            {
                singlea = value;
            }
        }

        public string Target
        {
            get
            {
                return target;
            }

            set
            {
                target = value;
            }
        }

        public string Water
        {
            get
            {
                return water;
            }

            set
            {
                water = value;
            }
        }

        public string Wings
        {
            get
            {
                return wings;
            }

            set
            {
                wings = value;
            }
        }
    }
    public class Blockname_Model
    {

        string name_block;

        public string Name_block
        {
            get
            {
                return name_block;
            }

            set
            {
                name_block = value;
            }
        }
    }
    public class Blocknameshe_Model
    {

        string blockname;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }
    }
    public class LuruData_Model
    {
        string ground_id,
            quantity,
            inject,
            water,
            gtarget,
            name_block;

        public string Ground_id
        {
            get
            {
                return ground_id;
            }

            set
            {
                ground_id = value;
            }
        }

        public string Gtarget
        {
            get
            {
                return gtarget;
            }

            set
            {
                gtarget = value;
            }
        }

        public string Inject
        {
            get
            {
                return inject;
            }

            set
            {
                inject = value;
            }
        }

        public string Name_block
        {
            get
            {
                return name_block;
            }

            set
            {
                name_block = value;
            }
        }

        public string Quantity
        {
            get
            {
                return quantity;
            }

            set
            {
                quantity = value;
            }
        }

        public string Water
        {
            get
            {
                return water;
            }

            set
            {
                water = value;
            }
        }
    }

    public class GroundImage_Model
    {

        string Groundimage_id,
        shuizhi1_top,//水质处理-一级
        shuizhi2_top,//水质处理-二级
        rongye1_top,//分散溶液-  单翼
        rongye2_top,//分散溶液-双翼
        shuhua1_top,//在线熟化
        shuhua2_top,//分散熟化
        weiru_top, //喂入方式
        mubiao1_top,//目标液注入
        mubiao2_top,//参水稀释
        zhuru1_top,//注入-单泵单井
        zhuru2_top;//注入-一泵多井;

        public string Groundimage_id1
        {
            get
            {
                return Groundimage_id;
            }

            set
            {
                Groundimage_id = value;
            }
        }

        public string Mubiao1_top
        {
            get
            {
                return mubiao1_top;
            }

            set
            {
                mubiao1_top = value;
            }
        }

        public string Mubiao2_top
        {
            get
            {
                return mubiao2_top;
            }

            set
            {
                mubiao2_top = value;
            }
        }

        public string Rongye1_top
        {
            get
            {
                return rongye1_top;
            }

            set
            {
                rongye1_top = value;
            }
        }

        public string Rongye2_top
        {
            get
            {
                return rongye2_top;
            }

            set
            {
                rongye2_top = value;
            }
        }

        public string Shuhua1_top
        {
            get
            {
                return shuhua1_top;
            }

            set
            {
                shuhua1_top = value;
            }
        }

        public string Shuhua2_top
        {
            get
            {
                return shuhua2_top;
            }

            set
            {
                shuhua2_top = value;
            }
        }

        public string Shuizhi1_top
        {
            get
            {
                return shuizhi1_top;
            }

            set
            {
                shuizhi1_top = value;
            }
        }

        public string Shuizhi2_top
        {
            get
            {
                return shuizhi2_top;
            }

            set
            {
                shuizhi2_top = value;
            }
        }

        public string Weiru_top
        {
            get
            {
                return weiru_top;
            }

            set
            {
                weiru_top = value;
            }
        }

        public string Zhuru1_top
        {
            get
            {
                return zhuru1_top;
            }

            set
            {
                zhuru1_top = value;
            }
        }

        public string Zhuru2_top
        {
            get
            {
                return zhuru2_top;
            }

            set
            {
                zhuru2_top = value;
            }
        }
    }
}