﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//层系组合技术优选Model   ctrl+R  ctrl+E
namespace TwoOrThreeCombination.Model
{
    public class LayerCombination_Model
    {
        string hierarchical_id, blockname, layer_group, deep_reservoir, deep_bottom, small_reservoir_group,
            permeability, pressure_factor, sand_production, reservoir_type;

        public string Blockname
        {
            get
            {
                return blockname;
            }

            set
            {
                blockname = value;
            }
        }

        public string Deep_bottom
        {
            get
            {
                return deep_bottom;
            }

            set
            {
                deep_bottom = value;
            }
        }

        public string Deep_reservoir
        {
            get
            {
                return deep_reservoir;
            }

            set
            {
                deep_reservoir = value;
            }
        }

        public string Hierarchical_id
        {
            get
            {
                return hierarchical_id;
            }

            set
            {
                hierarchical_id = value;
            }
        }

        public string Layer_group
        {
            get
            {
                return layer_group;
            }

            set
            {
                layer_group = value;
            }
        }

        public string Permeability
        {
            get
            {
                return permeability;
            }

            set
            {
                permeability = value;
            }
        }

        public string Pressure_factor
        {
            get
            {
                return pressure_factor;
            }

            set
            {
                pressure_factor = value;
            }
        }

        public string Reservoir_type
        {
            get
            {
                return reservoir_type;
            }

            set
            {
                reservoir_type = value;
            }
        }

        public string Sand_production
        {
            get
            {
                return sand_production;
            }

            set
            {
                sand_production = value;
            }
        }

        public string Small_reservoir_group
        {
            get
            {
                return small_reservoir_group;
            }

            set
            {
                small_reservoir_group = value;
            }
        }
    }
    public class LayerCom_OutParam_Model
    {
        string outparam_id, namecontrast, permeability_badly, permeability_variation, well_oil_number, reservoir_span,
            pressure_coefficient, are_consistent, solution_combinations;

        public string Are_consistent
        {
            get
            {
                return are_consistent;
            }

            set
            {
                are_consistent = value;
            }
        }

        public string Namecontrast
        {
            get
            {
                return namecontrast;
            }

            set
            {
                namecontrast = value;
            }
        }

        public string Outparam_id
        {
            get
            {
                return outparam_id;
            }

            set
            {
                outparam_id = value;
            }
        }

        public string Permeability_badly
        {
            get
            {
                return permeability_badly;
            }

            set
            {
                permeability_badly = value;
            }
        }

        public string Permeability_variation
        {
            get
            {
                return permeability_variation;
            }

            set
            {
                permeability_variation = value;
            }
        }

        public string Pressure_coefficient
        {
            get
            {
                return pressure_coefficient;
            }

            set
            {
                pressure_coefficient = value;
            }
        }

        public string Reservoir_span
        {
            get
            {
                return reservoir_span;
            }

            set
            {
                reservoir_span = value;
            }
        }

        public string Solution_combinations
        {
            get
            {
                return solution_combinations;
            }

            set
            {
                solution_combinations = value;
            }
        }

        public string Well_oil_number
        {
            get
            {
                return well_oil_number;
            }

            set
            {
                well_oil_number = value;
            }
        }
    }
}