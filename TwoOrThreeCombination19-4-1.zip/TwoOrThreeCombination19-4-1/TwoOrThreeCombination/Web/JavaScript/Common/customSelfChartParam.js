﻿
//////////////////////********************************************//////////////////////////////
//////////////////////************自定义右键点击图表事件**********//////////////////////////////
//////////////////////********************************************//////////////////////////////
//注：引用此js文件需要在之前引用如下js插件
//1.jquery.js
//2.bootstrap.js
//3.bootstrap-table.js
//4.select2.js
//5.jquery.cxcolor.js
//6.echarts.js
//另，echart图表需要配置好列表所包含的属性如系列名、颜色、最值等。

//操作的图表数据初始化
var operaChart = null;

//图表原始option数据
var chartOptionSource = null;
$(function () {

    //加载完成之后添加模态框
    $("body").append("<div class=\"modal fade\" id=\"customSelfModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"customSelfModallLabel\" aria-hidden=\"true\"><div class=\"modal-dialog\" style=\"width:80%;\"><div class=\"modal-content\" style=\"height:500px;\"><div class=\"modal-header\"><button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button><h4 class=\"modal-title\" id=\"customSelfModalLabel\">自定义图表属性</h4>\</div><div class=\"modal-body\" style=\"height:380px;\"><table id=\"customAttributeTable\"></table></div><div class=\"modal-footer\"><button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">关闭</button><button type=\"button\" id=\"drawThisChart\" class=\"btn btn-primary\">更新曲线</button></div></div></div></div>");

    //图形更新
    $("#drawThisChart").on("click", function () {
        var data = $("#customAttributeTable").bootstrapTable("getSelections");
        if (data.length <= 0) {
            msgShow("请选择要绘制的系列", "", 1200);
            return false;
        }

        var chartId = operaChart._dom.id;
        var newSeries = operaChart.getOption().series;
        var newYAxis = operaChart.getOption().yAxis;
        var newXAxis = operaChart.getOption().xAxis;
        var newColors = operaChart.getOption().color;
        var newLegendName = [];
        var newSelectedLegend = {};

        //series数据处理
        for (var i = 0; i < newSeries.length; i++) {
            //隐藏所有系列，并清空相应数据
            newSeries[i].show = false;
            newSeries[i].data = [];
            //隐藏所有纵坐标
            newYAxis[i].show = false;
            //纵坐标偏移设置为0
            newYAxis[i].offset = 0;
        }

        //隐藏所有横坐标
        for (var i = 0; i < newXAxis.length; i++) {
            newXAxis[i].show = false;
        }

        //遍历获取当前选中的图表的option
        var dataChartOptionSource = null;
        for (var i = 0; i < chartOptionSource.length; i++) {
            if (chartOptionSource[i].elementId == chartId) {
                dataChartOptionSource = chartOptionSource[i].chartOption;
                break;
            }
        }

        //纵坐标偏移量设置
        var offSetParam = 0;
        var isOneGrid = false;
        var indexStart = 0;
        //绘制曲线
        for (var i = 0; i < data.length; i++) {
            //加载选中的系列及数据
            newSeries[data[i].index - 1].show = true;
            newSeries[data[i].index - 1].data = dataChartOptionSource.series[data[i].index - 1].data;
            //获取选中的颜色
            var cxcolor = $("#cxcolor" + (data[i].index - 1)).cxColor();
            var colorSelected = "red";
            cxcolor.cxColor(function (api) {
                colorSelected = api.color();
            });

            newSelectedLegend[data[i].title] = true;
            newLegendName.push({
                name: data[i].title
            });

            //设置曲线颜色
            newColors[data[i].index - 1] = colorSelected;
            //加载选中的曲线属性
            var chartType = $("#seriesType" + (data[i].index - 1)).select2("data")[0].id == "" ? "line" : $("#seriesType" + (data[i].index - 1)).select2("data")[0].id;
            if (chartType == "lineNoSmooth") {
                newSeries[data[i].index - 1].smooth = false;
            }
            else {
                newSeries[data[i].index - 1].smooth = true;
                newSeries[data[i].index - 1].type = chartType;
            }
            //获取当前系列对应的Y轴索引
            var yAxisIndex = newSeries[data[i].index - 1].yAxisIndex;
            //加载选中的纵坐标及其属性
            newYAxis[yAxisIndex].show = true;

            //处理纵坐标偏移
            if (i - newYAxis[yAxisIndex].gridIndex < 0) {
                //说明只有grid2的数据被选中
                isOneGrid = true;
            }
            //设置开始列的系数
            if (i > 0 && newYAxis[yAxisIndex].gridIndex != newYAxis[newSeries[data[i - 1].index - 1].yAxisIndex].gridIndex) {
                indexStart = i;
            }

            if (isOneGrid) {
                offSetParam = i;
            }
            else {
                offSetParam = i - indexStart;
            }

            //纵坐标偏移量设置
            newYAxis[yAxisIndex].offset = offSetParam * 40;
            //纵坐标偏最大值、最小值、数值间隔设置
            newYAxis[yAxisIndex].max = $("#YMax" + (data[i].index - 1)).val();
            newYAxis[yAxisIndex].min = $("#YMin" + (data[i].index - 1)).val();
            newYAxis[yAxisIndex].interval = parseFloat($("#YInterval" + (data[i].index - 1)).val());
            //设置纵坐标颜色
            newYAxis[yAxisIndex].axisLine.lineStyle.color = colorSelected;
            //加载选中的横坐标
            newXAxis[newSeries[data[i].index - 1].xAxisIndex].show = true;

        }
        operaChart.setOption({
            series: newSeries,
            color: newColors,
            xAxis: newXAxis,
            yAxis: newYAxis,
            legend: {
                data: newLegendName,
                selected: newSelectedLegend
            }
        });

        //获取所有图表中Y轴个数最大值
        var gridXMax = [];

        //遍历获取非当前选中的图表的option所包含的Y轴个数
        for (var i = 0; i < chartOptionSource.length; i++) {
            gridXMax.push(0);
            if (chartOptionSource[i].elementId != chartId) {
                var chart_Temp = echarts.init(document.getElementById(chartOptionSource[i].elementId));
                for (var j = 0; j < chart_Temp.getOption().yAxis.length; j++) {
                    if (chart_Temp.getOption().yAxis[j].show) {
                        gridXMax[i]++;
                    }
                }
            }
        }
        //获取坐标轴最大个数
        var gridXValue = Math.max.apply(null, gridXMax) > (data.length) ? Math.max.apply(null, gridXMax) * 3 + "%" : (data.length * 3 + "%");

        //遍历获取非当前选中的图表的option所包含的Y轴个数
        for (var i = 0; i < chartOptionSource.length; i++) {
            //将图表设置为最大Y轴比例大小
            echarts.init(document.getElementById(chartOptionSource[i].elementId)).setOption({
                grid: [
                    { x: gridXValue, y: '15%'}
                ]
            });
        }
        //隐藏模态框
        $("#customSelfModal").modal("hide");
    });
});
//绑定右键点击事件
function bindContextMenuOnChart(chartData) {
    chartOptionSource = chartData;
    for (var i = 0; i < chartData.length; i++) {
        //注水综合曲线右键点击事件
        $("#" + chartData[i].elementId).on('contextmenu', function (event) {
            //阻止默认事件
            event.preventDefault();
            var chartName = "";
            //找到当前图表的名字
            for (var j = 0; j < chartOptionSource.length; j++) {
                if (chartOptionSource[j].elementId == event.currentTarget.id) {
                    chartName = chartOptionSource[j].chartName;
                    break;
                }
            }

            $("#customSelfModalLabel").html(chartName);
            createAttributeTable(echarts.init(document.getElementById(event.currentTarget.id)));
            $("#customSelfModal").modal("show");
        });
    }
}

//根据右键所选的图表加载属性表
function createAttributeTable(chart) {
    operaChart = chart;
    var option = chart.getOption();
    var tableData = [];
    var checkedData = [];
    //循环遍历需要选中的行数据
    for (var i = 0; i < option.yAxis.length; i++) {
        if (option.yAxis[i].show) {
            checkedData.push(i);
        }
    }
    //循环遍历数据，填充table
    for (var i = 0; i < option.series.length; i++) {
        tableData.push({
            index: i + 1,
            title: option.series[i].name,
            type: option.series[i].smooth == false ? (option.series[i].type == "line" ? "lineNoSmooth" : option.series[i].type) : option.series[i].type,
            color: option.color[i],
            YMax: option.yAxis[i].max,
            YMin: option.yAxis[i].min,
            YInterval: option.yAxis[i].interval
        });
    }

    //列表显示表属性
    $("#customAttributeTable").bootstrapTable("destroy");
    $("#customAttributeTable").bootstrapTable({
        columns: [
            {
                field: 'index',
                title: '序号',
                halign: "center",
                align: "center",
                valign: "middle"
            },
            {
                field: 'title',
                title: '系列名',
                halign: "center",
                align: "center",
                valign: "middle",
                formatter: function (value, row, index) {
                    return value;
                }
            },
            {
                field: 'type',
                title: '类型',
                valign: "middle",
                halign: "center",
                align: "center",
                formatter: function (value, row, index) {
                    return '<select class="seriesType" id="seriesType' + index + '" ></select>';
                }
            },
            {
                field: 'color',
                title: '颜色',
                halign: "center",
                align: "center",
                valign: "middle",
                formatter: function (value, row, index) {
                    return "<input id='cxcolor" + index + "' class='input_cxcolor' type='text' value='" + value + "'/>";
                }
            },
            {
                field: 'YMax',
                title: 'Y轴最大值',
                halign: "center",
                valign: "middle",
                formatter: function (value, row, index) {
                    return "<input id='YMax" + index + "' style='text-align:right;' class=\"form-control input-sm\" placeholder=\"请输入最大值\" type='text' value='" + value + "'/>";
                }
            },
            {
                field: 'YMin',
                title: 'Y轴最小值',
                halign: "center",
                valign: "middle",
                formatter: function (value, row, index) {
                    return "<input id='YMin" + index + "' style='text-align:right;' class=\"form-control input-sm\" placeholder=\"请输入最小值\" type='text' value='" + value + "'/>";
                }
            },
            {
                field: 'YInterval',
                halign: "center",
                valign: "middle",
                title: 'Y轴间隔',
                formatter: function (value, row, index) {
                    return "<input id='YInterval" + index + "' style='text-align:right;' class=\"form-control input-sm\" placeholder=\"请输入间隔\" type='text' value='" + value + "'/>";
                }
            },
            {
                field: 'isDraw',
                title: '是否绘制',
                valign: "middle",
                align: "center",
                formatter: function (value, row, index) {
                    return '<input name="btSelectItem" type="checkbox" data-index="' + index + '">';
                }
            }],
        data: tableData,
        onPostBody: function () {
            $(".input_cxcolor").cxColor();
            $(".seriesType").select2({
                placeholder: {
                    id: '-1', // the value of the option
                    text: "请选择类型"
                },
                width: 180,
                data:
                    [
                      {
                          "id": "line",
                          "text": "曲线"
                      },
                      {
                          "id": "lineNoSmooth",
                          "text": "折线"
                      },
                      {
                          "id": "bar",
                          "text": "柱状"
                      }
                    ]
            });
            //循环给曲线类型赋值
            for (var i = 0; i < tableData.length; i++) {
                $("#seriesType" + i).val(tableData[i].type).trigger("change");
            }
        }
    });
    //选中当前右键点击的图表所对应的数据
    for (var i = 0; i < checkedData.length; i++) {
        $("#customAttributeTable").bootstrapTable("check",checkedData[i]);
    }
    ////默认选中所有
    //$("#customAttributeTable").bootstrapTable("checkAll");
}

////图表大小自适应
//$(window).resize(function () {
//    //遍历获取非当前选中的图表的option所包含的Y轴个数
//    for (var i = 0; i < chartOptionSource.length; i++) {
//        echarts.init(document.getElementById(chartOptionSource[i].elementId)).resize();
//    }
//});

