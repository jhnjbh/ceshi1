﻿function client() {
    if (window.innerWidth != null && window.innerWidth != 0) {//兼容 IE9以上 及 现代的浏览器
        //如果window.innerWidth不是空且不是0
        return {//花括号一定不能换行到下一行，否则返回空
            // return 的内容一定要和return在同一行，不能换行
            width: window.innerWidth,
            height: window.innerHeight
        }
    } else if (document.compatMode === "CSS1Compat" && document.documentElement.clientWidth != 0) {//标准浏览器，有<!DOCTYPE html>声明的
        //如果document.documentElement.clientWidth不是空且不是0
        return {
            width: document.documentElement.clientWidth,
            height: document.documentElement.clientHeight
        }
    } else if (document.body.clientWidth !=null && document.body.clientWidth != 0) {//怪异浏览器，没有<!DOCTYPE html>声明的
        //如果document.body.clientWidth不是空且不是0
        return {
            width: document.body.clientWidth,
            height: document.body.clientHeight
        }
    } else if (window.outerWidth != null && window.outerWidth != 0) {//怪异浏览器，没有<!DOCTYPE html>声明的
        //如果window.outerWidth不是0
        return {
            width: window.outerWidth - 355,
            height: window.outerHeight - 175
        }
    } else {
        //返回固定值
        return {
            width: 1000,
            height: 600
        }
    }
}