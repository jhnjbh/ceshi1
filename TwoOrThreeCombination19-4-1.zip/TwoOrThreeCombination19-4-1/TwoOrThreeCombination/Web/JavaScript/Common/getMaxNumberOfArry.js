﻿//**********************************//
//**     获取数组中的最值         **//
//**********************************//

//初始化对象
var MaxNumberOfArry = {};
//原始数组
MaxNumberOfArry.Arry = [];
//最大值
MaxNumberOfArry.maxValue;
//获取方法
MaxNumberOfArry.getMaxNumber = function () {
    //初始化所求最值为“-”
    this.maxValue = "-";
    if (isNaN(Math.max.apply(null, this.Arry))) {
        //如果数组中存在非数字字符
        for (var i = 0; i < this.Arry.length; i++) {
            //尝试将数组内容转换为数字
            var thisValue = isNaN(parseFloat(this.Arry[i]));
            if (thisValue) {
                //如果该字符不可转换为数字，则继续
                continue;
            }
            else {
                if (isNaN(this.maxValue)) {
                    //如果最值未赋值，则进行赋值
                    this.maxValue = parseFloat(this.Arry[i]);
                }
                else {
                    //如果最值已存在值，则进行比较并赋值
                    this.maxValue = this.maxValue < parseFloat(this.Arry[i]) ? parseFloat(this.Arry[i]) : parseFloat(this.maxValue);
                }
            }
        }
    }
    else {
        //数组中不存在非数字字符，直接得出结果
        this.maxValue = Math.max.apply(null, this.Arry);
    }
    return this.maxValue;
}