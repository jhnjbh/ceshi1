﻿using DAL;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.SessionState;
using TwoOrThreeCombination.DB;
using TwoOrThreeCombination.Model;

namespace TwoOrThreeCombination
{
    /// <summary>
    /// Login 的摘要说明
    /// </summary>
    public class Login : IHttpHandler, IRequiresSessionState
    {

        dal dal = new dal();
        public void ProcessRequest(HttpContext context)
        {
            string type = context.Request["type"];
            if (type == "log")
            {
                StreamReader stream = new StreamReader(context.Request.InputStream);
                string payload = stream.ReadToEnd();
                string username = "";
                string password = "";
                //将数据转换为JArray对象
                try
                {
                    JObject data = JObject.Parse(payload);
                    username = data["username"].ToString();
                    password = data["password"].ToString();
                    type = data["type"].ToString();
                }
                catch (Exception ex)
                {
                }
                context.Response.ContentType = "text/plain";
                context.Response.Write(getLogin(username, password, type, context));
            }

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public string getLogin(string username, string password, string type, HttpContext context)
        {
            string result = "";
            if (type == "1")
            {
                DataSet ds_selUserName = new DataSet();
                DataSet ds = null;
                string[] sqlStrKey = { "@USERNAME", "@PASSWORD" };
                string[] sqlIntKey = { };
                int[] sqlIntValue = { };
                string[] sqlStrValue = { username, password };
                ds_selUserName = dal.selAll2(sqlStrKey, sqlStrValue, sqlIntValue, sqlIntKey, "sp_checkLogin");
                if (ds_selUserName.Tables[0].Rows.Count > 0)
                {
                    string[] StrKey = { "@USERNAME" };
                    string[] IntKey = { };
                    int[] IntValue = { };
                    string[] StrValue = { username };
                    try
                    {
                        ds = dal.selAll2(StrKey, StrValue, IntValue, IntKey, "sp_selUserPermission");
                    }
                    catch (Exception e)
                    {

                    }
                    if (ds != null)
                    {
                        string permission = "";
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            permission += ds.Tables[0].Rows[i]["PER_NAME"].ToString() + ",";
                        }
                        permission = permission.Substring(0, permission.Length - 1);
                        context.Session["Permission"] = permission;
                        result = "{\"Login\": \"../es/Index.html\", \"Permission\": \"" + permission + "\"}";
                        //result = "{\"Login\": \"../Index.html\", \"Permission\": \"" + permission + "\"}";
                    }
                    else
                    {
                        result = "{\"Login\": \"../es/Index.html\", \"Permission\": \"\"}";
                        //result = "{\"Login\": \"../Index.html\", \"Permission\": \"\"}";
                    }
                }
                else
                {
                    result = "{\"Login\": \"false\", \"Permission\": \"\"}";
                }
            }
            else
            {
                result = "{\"Login\": \"false\", \"Permission\": \"\"}";
                //Base64Help base64 = new Base64Help();
                //string postDataStr = base64.Base64Encode(username.ToString().Trim() + "," + password.Trim());
                //string getDataStr = base64.Base64Encode(username.ToString().Trim() + ":" + password.Trim());
                //string url = "http://uiap.dgyt.petrochina/dguac/api/authentication";
                //string jo = json.HttpGet(url, postDataStr, getDataStr);
            }
            return result;
        }
    }
}