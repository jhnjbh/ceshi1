﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Script.Serialization;

namespace DAL
{
    public class getDataTableColumnsName
    {
        /// <summary>
        /// 获取DataTable的列名
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public string[] GetColumnsByDataTable(DataTable dt)
        {
            string[] strColumns = null;
            if (dt != null && dt.Columns.Count > 0)
            {
                int columnNum = 0;
                columnNum = dt.Columns.Count;
                strColumns = new string[columnNum];
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    strColumns[i] = dt.Columns[i].ColumnName;
                }
            }
            return strColumns;
        }
        /// <summary>
        /// 根据传递的类和datatable获取序列化之后的字符串
        /// </summary>
        /// <param name="T"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public string getSerilizerString(object T,DataTable dt) {
            List<object> list = new List<object>();
            getDataTableColumnsName getName = new getDataTableColumnsName();
            string[] tableColumnsName = getName.GetColumnsByDataTable(dt);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                object tCopy = CloneObject(T);
                //遍历injDaily的属性
                foreach (PropertyInfo prop in tCopy.GetType().GetProperties())
                {
                    //循环遍历列名
                    for (int j = 0; j < tableColumnsName.Length; j++)
                    {
                        //实体类属性名称转换为大写与表列名比较
                        if (prop.Name.ToUpper() == tableColumnsName[j])
                        {
                            //如果列名和属性名一致，则赋值
                            prop.SetValue(tCopy, dt.Rows[i][tableColumnsName[j]].Equals(DBNull.Value) ? "" : dt.Rows[i][tableColumnsName[j]].ToString(), null);
                            break;
                        }
                    }
                }
                list.Add(tCopy);
            }
            JavaScriptSerializer jss = new JavaScriptSerializer();
            return jss.Serialize(list);
        }
        /// <summary>
        /// 根据传递的类和datatable获取序列化之后的modal链表
        /// </summary>
        /// <param name="T"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        public List<object> getSerilizerList(object T, DataTable dt)
        {
            List<object> list = new List<object>();
            getDataTableColumnsName getName = new getDataTableColumnsName();
            string[] tableColumnsName = getName.GetColumnsByDataTable(dt);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                object tCopy = CloneObject(T);
                //遍历injDaily的属性
                foreach (PropertyInfo prop in tCopy.GetType().GetProperties())
                {
                    //循环遍历列名
                    for (int j = 0; j < tableColumnsName.Length; j++)
                    {
                        //实体类属性名称转换为大写与表列名比较
                        if (prop.Name.ToUpper() == tableColumnsName[j])
                        {
                            //如果列名和属性名一致，则赋值
                            prop.SetValue(tCopy, dt.Rows[i][tableColumnsName[j]].Equals(DBNull.Value) ? "" : dt.Rows[i][tableColumnsName[j]].ToString(), null);
                            break;
                        }
                    }
                }
                list.Add(tCopy);
            }
            return list;
        }
        /// <summary>
        /// 克隆一个对象
        /// </summary>
        /// <param name="o"></param>
        /// <returns></returns>
        public object CloneObject(object o)
        {
            Type t = o.GetType();
            PropertyInfo[] properties = t.GetProperties();
            Object p = t.InvokeMember("", System.Reflection.BindingFlags.CreateInstance, null, o, null);
            foreach (PropertyInfo pi in properties)
            {
                if (pi.CanWrite)
                {
                    object value = pi.GetValue(o, null);
                    pi.SetValue(p, value, null);
                }
            }
            return p;
        }
    }
}