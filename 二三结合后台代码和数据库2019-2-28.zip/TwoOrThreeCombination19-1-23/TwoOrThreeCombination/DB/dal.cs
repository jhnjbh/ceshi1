﻿using DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace TwoOrThreeCombination.DB
{
    public class dal
    {
        #region 初始化数据库连接
        /// <summary>
        /// 初始化数据库连接
        /// </summary>
        /// <returns></returns>
        private SqlConnection DConn()
        {
            SqlConnection dconn = new SqlConnection();//新建数据库连接

            dconn.ConnectionString = ConfigurationManager.ConnectionStrings["ESipDB"].ToString();//数据库连接            
            dconn.Open();//打开数据库连接
            return dconn;
        }
        #endregion
        #region 初始化sqlCOMMAND
        /// <summary>
        /// 初始化COMMAND
        /// </summary>
        /// <param name="conn"></param>
        /// <returns></returns>
        private SqlCommand DCmd(SqlConnection conn)
        {
            SqlCommand dcmd = new SqlCommand();//实例化sqlcommand
            dcmd.Connection = conn;
            dcmd.CommandType = CommandType.StoredProcedure;
            return dcmd;
        }
        #endregion
        #region 孙旸 查询所有
        public DataSet selAll(string[] sqlStrKey, string[] sqlStrValue, int[] sqlIntValue, string[] sqlIntKey, string sp_name)
        {
            SqlConnection conn = DConn();
            SqlCommand cmd_SelectAuthor = DCmd(conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd_SelectAuthor);
            DataSet ds = new DataSet();

            if (sqlStrKey.Length > 0)
            {
                foreach (string str in sqlStrKey)
                {
                    cmd_SelectAuthor.Parameters.Add(str, SqlDbType.NVarChar);
                }
            }

            if (sqlIntKey.Length > 0)
            {
                foreach (string str in sqlIntKey)
                {
                    cmd_SelectAuthor.Parameters.Add(str, SqlDbType.Int);
                }
            }

            if (sqlStrValue.Length > 0)
            {
                for (int i = 0; i < sqlStrValue.Length; i++)
                {
                    cmd_SelectAuthor.Parameters[i].Value = sqlStrValue[i];
                }
            }

            if (sqlIntValue.Length > 0)
            {
                for (int i = 0; i < sqlIntValue.Length; i++)
                {
                    cmd_SelectAuthor.Parameters[i + sqlStrValue.Length].Value = sqlIntValue[i];
                }
            }

            cmd_SelectAuthor.CommandText = sp_name;
            conn.Close();
            try
            {
                da.Fill(ds);

                return ds;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        #endregion
        #region 孙旸 添加/修改数据
        public bool addOrAlterData(string[] sqlStrKey, string[] sqlStrValue, int[] sqlIntValue, string[] sqlIntKey, string sp_name)
        {
            SqlConnection conn = DConn();
            SqlCommand cmd_SelectAuthor = DCmd(conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd_SelectAuthor);
            DataSet ds = new DataSet();
            if (sqlStrKey.Length > 0)
            {
                foreach (string str in sqlStrKey)
                {
                    cmd_SelectAuthor.Parameters.Add(str, SqlDbType.NVarChar);
                }
            }

            if (sqlIntKey.Length > 0)
            {
                foreach (string str in sqlIntKey)
                {
                    cmd_SelectAuthor.Parameters.Add(str, SqlDbType.Int);
                }
            }

            if (sqlStrValue.Length > 0)
            {
                for (int i = 0; i < sqlStrValue.Length; i++)
                {
                    cmd_SelectAuthor.Parameters[i].Value = sqlStrValue[i];
                }
            }

            if (sqlIntValue.Length > 0)
            {
                for (int i = 0; i < sqlIntValue.Length; i++)
                {
                    cmd_SelectAuthor.Parameters[i + sqlStrValue.Length].Value = sqlIntValue[i];
                }
            }


            cmd_SelectAuthor.CommandText = sp_name;

            try { cmd_SelectAuthor.ExecuteNonQuery(); conn.Close(); return true; }
            catch(Exception ex) { conn.Close(); return false; }

        }
        #endregion
        #region 孙旸 删除
        public bool delId(int id, string sp_name)
        {
            SqlCommand cmd_SelectAuthor = DCmd(DConn());
            SqlDataAdapter da = new SqlDataAdapter(cmd_SelectAuthor);
            DataSet ds = new DataSet();
            cmd_SelectAuthor.Parameters.Add("@id", SqlDbType.Int);
            cmd_SelectAuthor.Parameters[0].Value = id;
            cmd_SelectAuthor.CommandText = sp_name;
            try
            {
                cmd_SelectAuthor.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion

        #region 删除举升工艺
        public bool delProcessMatchingProgram(string PROGRAMNAME, string WELL_SITE, string WELL_NUM)
        {
            SqlCommand cmd_SelectAuthor = DCmd(DConn());
            SqlDataAdapter da = new SqlDataAdapter(cmd_SelectAuthor);
            DataSet ds = new DataSet();
            cmd_SelectAuthor.Parameters.Add("@PROGRAMNAME", SqlDbType.NVarChar);
            cmd_SelectAuthor.Parameters.Add("@WELL_SITE", SqlDbType.NVarChar);
            cmd_SelectAuthor.Parameters.Add("@WELL_NUM", SqlDbType.NVarChar);
            cmd_SelectAuthor.Parameters[0].Value = PROGRAMNAME;
            cmd_SelectAuthor.Parameters[1].Value = WELL_SITE;
            cmd_SelectAuthor.Parameters[2].Value = WELL_NUM;
            cmd_SelectAuthor.CommandText = "sp_delProcessMatchingProgram";
            try
            {
                cmd_SelectAuthor.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion
        #region 初始化数据库连接
        /// <summary>
        /// 初始化数据库连接
        /// </summary>
        /// <returns></returns>
        private SqlConnection DConn2()
        {
            SqlConnection dconn = new SqlConnection();//新建数据库连接

            //dconn.ConnectionString = ConfigurationManager.ConnectionStrings["ESipDBUserTest"].ToString();//本地数据库连接      
            dconn.ConnectionString = ConfigurationManager.ConnectionStrings["ESipDBUserTest"].ToString();//大港数据库连接       
            dconn.Open();//打开数据库连接
            return dconn;
        }
        #endregion
        #region 孙旸 查询所有
        public DataSet selAll2(string[] sqlStrKey, string[] sqlStrValue, int[] sqlIntValue, string[] sqlIntKey, string sp_name)
        {
            SqlConnection conn = DConn2();
            SqlCommand cmd_SelectAuthor = DCmd(conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd_SelectAuthor);
            DataSet ds = new DataSet();

            if (sqlStrKey.Length > 0)
            {
                foreach (string str in sqlStrKey)
                {
                    cmd_SelectAuthor.Parameters.Add(str, SqlDbType.NVarChar);
                }
            }

            if (sqlIntKey.Length > 0)
            {
                foreach (string str in sqlIntKey)
                {
                    cmd_SelectAuthor.Parameters.Add(str, SqlDbType.Int);
                }
            }

            if (sqlStrValue.Length > 0)
            {
                for (int i = 0; i < sqlStrValue.Length; i++)
                {
                    cmd_SelectAuthor.Parameters[i].Value = sqlStrValue[i];
                }
            }

            if (sqlIntValue.Length > 0)
            {
                for (int i = 0; i < sqlIntValue.Length; i++)
                {
                    cmd_SelectAuthor.Parameters[i + sqlStrValue.Length].Value = sqlIntValue[i];
                }
            }

            cmd_SelectAuthor.CommandText = sp_name;
            conn.Close();
            try
            {
                da.Fill(ds);

                return ds;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        #endregion
        #region 孙旸 添加/修改数据
        public bool addOrAlterData2(string[] sqlStrKey, string[] sqlStrValue, int[] sqlIntValue, string[] sqlIntKey, string sp_name)
        {
            SqlConnection conn = DConn2();
            SqlCommand cmd_SelectAuthor = DCmd(conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd_SelectAuthor);
            DataSet ds = new DataSet();
            if (sqlStrKey.Length > 0)
            {
                foreach (string str in sqlStrKey)
                {
                    cmd_SelectAuthor.Parameters.Add(str, SqlDbType.NVarChar);
                }
            }

            if (sqlIntKey.Length > 0)
            {
                foreach (string str in sqlIntKey)
                {
                    cmd_SelectAuthor.Parameters.Add(str, SqlDbType.Int);
                }
            }

            if (sqlStrValue.Length > 0)
            {
                for (int i = 0; i < sqlStrValue.Length; i++)
                {
                    cmd_SelectAuthor.Parameters[i].Value = sqlStrValue[i];
                }
            }

            if (sqlIntValue.Length > 0)
            {
                for (int i = 0; i < sqlIntValue.Length; i++)
                {
                    cmd_SelectAuthor.Parameters[i + sqlStrValue.Length].Value = sqlIntValue[i];
                }
            }


            cmd_SelectAuthor.CommandText = sp_name;

            try { cmd_SelectAuthor.ExecuteNonQuery(); conn.Close(); return true; }
            catch (Exception e) { conn.Close(); return false; }

        }
        #endregion
        #region 孙旸 删除
        public bool delRoleName(string role_name, string sp_name)
        {
            SqlCommand cmd_SelectAuthor = DCmd(DConn2());
            SqlDataAdapter da = new SqlDataAdapter(cmd_SelectAuthor);
            DataSet ds = new DataSet();
            cmd_SelectAuthor.Parameters.Add("@Role_name", SqlDbType.NVarChar);
            cmd_SelectAuthor.Parameters[0].Value = role_name;
            cmd_SelectAuthor.CommandText = sp_name;
            try
            {
                cmd_SelectAuthor.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion
        #region 孙旸 删除
        public bool delUserName(string user_name, string sp_name)
        {
            SqlCommand cmd_SelectAuthor = DCmd(DConn2());
            SqlDataAdapter da = new SqlDataAdapter(cmd_SelectAuthor);
            DataSet ds = new DataSet();
            cmd_SelectAuthor.Parameters.Add("@USERNAME", SqlDbType.NVarChar);
            cmd_SelectAuthor.Parameters[0].Value = user_name;
            cmd_SelectAuthor.CommandText = sp_name;
            try
            {
                cmd_SelectAuthor.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        #endregion
    }
}