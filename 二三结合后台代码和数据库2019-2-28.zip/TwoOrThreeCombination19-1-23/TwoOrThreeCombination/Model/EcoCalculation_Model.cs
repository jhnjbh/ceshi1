﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwoOrThreeCombination.Model
{
    public class EcoCalculation_Model
    {
    }
    public class ActualityTables_Model
    {
        string actuality_id,
            oilwell,
            materials,
            actwork,
            direct,
            waterwells,

            fuel,
            test,
            factmines,
            oilmass,
            powers,

            repair,
            liquidmea,
            personnel,
            recoverys,
            watermass,

            injection,
            oilmanage,
            airflow,
            therecovery,
            transport,
            all;
        public string All
        {
            get
            {
                return all;
            }

            set
            {
                all = value;
            }
        }
        public string Actuality_id
        {
            get
            {
                return actuality_id;
            }

            set
            {
                actuality_id = value;
            }
        }

        public string Actwork
        {
            get
            {
                return actwork;
            }

            set
            {
                actwork = value;
            }
        }

        public string Airflow
        {
            get
            {
                return airflow;
            }

            set
            {
                airflow = value;
            }
        }

        public string Direct
        {
            get
            {
                return direct;
            }

            set
            {
                direct = value;
            }
        }

        public string Factmines
        {
            get
            {
                return factmines;
            }

            set
            {
                factmines = value;
            }
        }

        public string Fuel
        {
            get
            {
                return fuel;
            }

            set
            {
                fuel = value;
            }
        }

        public string Injection
        {
            get
            {
                return injection;
            }

            set
            {
                injection = value;
            }
        }

        public string Liquidmea
        {
            get
            {
                return liquidmea;
            }

            set
            {
                liquidmea = value;
            }
        }

        public string Materials
        {
            get
            {
                return materials;
            }

            set
            {
                materials = value;
            }
        }

        public string Oilmanage
        {
            get
            {
                return oilmanage;
            }

            set
            {
                oilmanage = value;
            }
        }

        public string Oilmass
        {
            get
            {
                return oilmass;
            }

            set
            {
                oilmass = value;
            }
        }

        public string Oilwell
        {
            get
            {
                return oilwell;
            }

            set
            {
                oilwell = value;
            }
        }

        public string Personnel
        {
            get
            {
                return personnel;
            }

            set
            {
                personnel = value;
            }
        }

        public string Powers
        {
            get
            {
                return powers;
            }

            set
            {
                powers = value;
            }
        }

        public string Recoverys
        {
            get
            {
                return recoverys;
            }

            set
            {
                recoverys = value;
            }
        }

        public string Repair
        {
            get
            {
                return repair;
            }

            set
            {
                repair = value;
            }
        }

        public string Test
        {
            get
            {
                return test;
            }

            set
            {
                test = value;
            }
        }

        public string Therecovery
        {
            get
            {
                return therecovery;
            }

            set
            {
                therecovery = value;
            }
        }

        public string Transport
        {
            get
            {
                return transport;
            }

            set
            {
                transport = value;
            }
        }

        public string Watermass
        {
            get
            {
                return watermass;
            }

            set
            {
                watermass = value;
            }
        }

        public string Waterwells
        {
            get
            {
                return waterwells;
            }

            set
            {
                waterwells = value;
            }
        }
    }
    public class WellinvestTables_Model
    {
        string years, allyearpice, allpice;//unitprice

        public string Allpice
        {
            get
            {
                return allpice;
            }

            set
            {
                allpice = value;
            }
        }

        public string Allyearpice
        {
            get
            {
                return allyearpice;
            }

            set
            {
                allyearpice = value;
            }
        }

        public string Years
        {
            get
            {
                return years;
            }

            set
            {
                years = value;
            }
        }
    }
    public class FigureTables_Model
    {
        string
            figureid,
            blockname,
            scenarioname,
            construction,
            interior,
            netweight,
            recycle,
            putinto,
            cost,
            implement;

        public string Figureid { get { return figureid; } set { figureid = value; } }
        public string Blockname { get { return blockname; } set { blockname = value; } }
        public string Scenarioname { get { return scenarioname; } set { scenarioname = value; } }
        public string Construction { get { return construction; } set { construction = value; } }
        public string Interior { get { return interior; } set { interior = value; } }
        public string Netweight { get { return netweight; } set { netweight = value; } }
        public string Recycle { get { return recycle; } set { recycle = value; } }
        public string Putinto { get { return putinto; } set { putinto = value; } }
        public string Cost { get { return cost; } set { cost = value; } }
        public string Implement { get { return implement; } set { implement = value; } }
    }


}