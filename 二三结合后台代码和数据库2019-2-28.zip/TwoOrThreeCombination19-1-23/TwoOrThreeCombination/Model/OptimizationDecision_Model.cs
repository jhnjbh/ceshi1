﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwoOrThreeCombination.Model
{
    public class OptimizationDecision_Model
    {
        string decision_id,
            oil_pool,
            craft,
            increase,
            interior,
            score,
            implement,
            decision_choose,
            neibuscore;

        public string Craft
        {
            get
            {
                return craft;
            }

            set
            {
                craft = value;
            }
        }

        public string Decision_choose
        {
            get
            {
                return decision_choose;
            }

            set
            {
                decision_choose = value;
            }
        }

        public string Decision_id
        {
            get
            {
                return decision_id;
            }

            set
            {
                decision_id = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Increase
        {
            get
            {
                return increase;
            }

            set
            {
                increase = value;
            }
        }

        public string Interior
        {
            get
            {
                return interior;
            }

            set
            {
                interior = value;
            }
        }

        public string Neibuscore
        {
            get
            {
                return neibuscore;
            }

            set
            {
                neibuscore = value;
            }
        }

        public string Oil_pool
        {
            get
            {
                return oil_pool;
            }

            set
            {
                oil_pool = value;
            }
        }

        public string Score
        {
            get
            {
                return score;
            }

            set
            {
                score = value;
            }
        }
    }
}