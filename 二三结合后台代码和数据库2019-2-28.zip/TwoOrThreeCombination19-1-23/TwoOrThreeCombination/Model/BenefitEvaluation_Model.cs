﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwoOrThreeCombination.Model
{
    public class BenefitEvaluation_Model
    {

        string implement,
            well_pattern,
            well_spacing,
            displacing_medium,
            recoveryrate,
            interior;

        public string Displacing_medium
        {
            get
            {
                return displacing_medium;
            }

            set
            {
                displacing_medium = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Interior
        {
            get
            {
                return interior;
            }

            set
            {
                interior = value;
            }
        }

        public string Recoveryrate
        {
            get
            {
                return recoveryrate;
            }

            set
            {
                recoveryrate = value;
            }
        }

        public string Well_pattern
        {
            get
            {
                return well_pattern;
            }

            set
            {
                well_pattern = value;
            }
        }

        public string Well_spacing
        {
            get
            {
                return well_spacing;
            }

            set
            {
                well_spacing = value;
            }
        }
    }
}