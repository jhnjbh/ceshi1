﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//驱替介质技术优选
namespace TwoOrThreeCombination.Model
{
    public class DisplacementMedium_Model
    {
        string displacing_id, the_name_block, implement,formation_temperature, divalent_ion, formation_crude,
            air_permeability, depth_reservoir, formation_water, permeability_variation, reservoir_rock,
            relative_density, remaining_crude, reservoir_pressure, reservoir_angle, reservoir_temperature, porosity,
            displa_choose, lvla, lvlb, lvlb2, lvlc, lvld;

        public string Air_permeability
        {
            get
            {
                return air_permeability;
            }

            set
            {
                air_permeability = value;
            }
        }

        public string Depth_reservoir
        {
            get
            {
                return depth_reservoir;
            }

            set
            {
                depth_reservoir = value;
            }
        }

        public string Displacing_id
        {
            get
            {
                return displacing_id;
            }

            set
            {
                displacing_id = value;
            }
        }

        public string Displa_choose
        {
            get
            {
                return displa_choose;
            }

            set
            {
                displa_choose = value;
            }
        }

        public string Divalent_ion
        {
            get
            {
                return divalent_ion;
            }

            set
            {
                divalent_ion = value;
            }
        }

        public string Formation_crude
        {
            get
            {
                return formation_crude;
            }

            set
            {
                formation_crude = value;
            }
        }

        public string Formation_temperature
        {
            get
            {
                return formation_temperature;
            }

            set
            {
                formation_temperature = value;
            }
        }

        public string Formation_water
        {
            get
            {
                return formation_water;
            }

            set
            {
                formation_water = value;
            }
        }

        public string Implement
        {
            get
            {
                return implement;
            }

            set
            {
                implement = value;
            }
        }

        public string Lvla
        {
            get
            {
                return lvla;
            }

            set
            {
                lvla = value;
            }
        }

        public string Lvlb
        {
            get
            {
                return lvlb;
            }

            set
            {
                lvlb = value;
            }
        }

        public string Lvlb2
        {
            get
            {
                return lvlb2;
            }

            set
            {
                lvlb2 = value;
            }
        }

        public string Lvlc
        {
            get
            {
                return lvlc;
            }

            set
            {
                lvlc = value;
            }
        }

        public string Lvld
        {
            get
            {
                return lvld;
            }

            set
            {
                lvld = value;
            }
        }

        public string Permeability_variation
        {
            get
            {
                return permeability_variation;
            }

            set
            {
                permeability_variation = value;
            }
        }

        public string Porosity
        {
            get
            {
                return porosity;
            }

            set
            {
                porosity = value;
            }
        }

        public string Relative_density
        {
            get
            {
                return relative_density;
            }

            set
            {
                relative_density = value;
            }
        }

        public string Remaining_crude
        {
            get
            {
                return remaining_crude;
            }

            set
            {
                remaining_crude = value;
            }
        }

        public string Reservoir_angle
        {
            get
            {
                return reservoir_angle;
            }

            set
            {
                reservoir_angle = value;
            }
        }

        public string Reservoir_pressure
        {
            get
            {
                return reservoir_pressure;
            }

            set
            {
                reservoir_pressure = value;
            }
        }

        public string Reservoir_rock
        {
            get
            {
                return reservoir_rock;
            }

            set
            {
                reservoir_rock = value;
            }
        }

        public string Reservoir_temperature
        {
            get
            {
                return reservoir_temperature;
            }

            set
            {
                reservoir_temperature = value;
            }
        }

        public string The_name_block
        {
            get
            {
                return the_name_block;
            }

            set
            {
                the_name_block = value;
            }
        }
    }
    public class DisplacementAll_Model
    {
        string displacing_id, the_name_block, formation_temperature, divalent_ion, formation_crude,
            air_permeability, depth_reservoir, formation_water, permeability_variation, reservoir_rock,
            relative_density, remaining_crude, reservoir_pressure, reservoir_angle, reservoir_temperature, porosity, displa_choose,
            polymer, chemistry, chemistry2, air, naturalgas;
        public string Displa_choose
        {
            get
            {
                return displa_choose;
            }

            set
            {
                displa_choose = value;
            }
        }
        public string Air
        {
            get
            {
                return air;
            }

            set
            {
                air = value;
            }
        }

        public string Air_permeability
        {
            get
            {
                return air_permeability;
            }

            set
            {
                air_permeability = value;
            }
        }

        public string Chemistry
        {
            get
            {
                return chemistry;
            }

            set
            {
                chemistry = value;
            }
        }
        public string Chemistry2
        {
            get
            {
                return chemistry2;
            }

            set
            {
                chemistry2 = value;
            }
        }
        public string Depth_reservoir
        {
            get
            {
                return depth_reservoir;
            }

            set
            {
                depth_reservoir = value;
            }
        }

        public string Displacing_id
        {
            get
            {
                return displacing_id;
            }

            set
            {
                displacing_id = value;
            }
        }

        public string Divalent_ion
        {
            get
            {
                return divalent_ion;
            }

            set
            {
                divalent_ion = value;
            }
        }

        public string Formation_crude
        {
            get
            {
                return formation_crude;
            }

            set
            {
                formation_crude = value;
            }
        }

        public string Formation_temperature
        {
            get
            {
                return formation_temperature;
            }

            set
            {
                formation_temperature = value;
            }
        }

        public string Formation_water
        {
            get
            {
                return formation_water;
            }

            set
            {
                formation_water = value;
            }
        }

        public string Naturalgas
        {
            get
            {
                return naturalgas;
            }

            set
            {
                naturalgas = value;
            }
        }

        public string Permeability_variation
        {
            get
            {
                return permeability_variation;
            }

            set
            {
                permeability_variation = value;
            }
        }

        public string Polymer
        {
            get
            {
                return polymer;
            }

            set
            {
                polymer = value;
            }
        }

        public string Porosity
        {
            get
            {
                return porosity;
            }

            set
            {
                porosity = value;
            }
        }

        public string Relative_density
        {
            get
            {
                return relative_density;
            }

            set
            {
                relative_density = value;
            }
        }

        public string Remaining_crude
        {
            get
            {
                return remaining_crude;
            }

            set
            {
                remaining_crude = value;
            }
        }

        public string Reservoir_angle
        {
            get
            {
                return reservoir_angle;
            }

            set
            {
                reservoir_angle = value;
            }
        }

        public string Reservoir_pressure
        {
            get
            {
                return reservoir_pressure;
            }

            set
            {
                reservoir_pressure = value;
            }
        }

        public string Reservoir_rock
        {
            get
            {
                return reservoir_rock;
            }

            set
            {
                reservoir_rock = value;
            }
        }

        public string Reservoir_temperature
        {
            get
            {
                return reservoir_temperature;
            }

            set
            {
                reservoir_temperature = value;
            }
        }

        public string The_name_block
        {
            get
            {
                return the_name_block;
            }

            set
            {
                the_name_block = value;
            }
        }
    }
}