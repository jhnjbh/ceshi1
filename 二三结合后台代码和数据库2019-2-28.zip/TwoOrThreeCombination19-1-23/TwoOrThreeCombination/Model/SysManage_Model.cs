﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwoOrThreeCombination.Model
{
    public class SysManage_Model
    {
        string id, per_name, per_id;

        public string Id { get { return id; } set { id = value; } }
        public string Per_name { get { return per_name; } set { per_name = value; } }
        public string Per_id { get { return per_id; } set { per_id = value; } }
    }
    public class User_Model
    {
        string username, password, isad, realname, sex, tel, role_name;

        public string Username { get { return username; } set { username = value; } }
        public string Password { get { return password; } set { password = value; } }
        public string Isad { get { return isad; } set { isad = value; } }
        public string Realname { get { return realname; } set { realname = value; } }
        public string Sex { get { return sex; } set { sex = value; } }
        public string Tel { get { return tel; } set { tel = value; } }
        public string Role_name { get { return role_name; } set { role_name = value; } }
    }
    public class Role_Model
    {
        string role_name;


        public string Role_name { get { return role_name; } set { role_name = value; } }
    }
}