﻿

//负责获取页面地址?后的值
function getKeyValue(key) {
    return getUrlKeyValue(window.location.search, key);
}
function getUrlKeyValue(url, key) {
    if (url.indexOf("?") >= 0) {
        url = url.substr(url.indexOf("?"));
    }
    var canshuji = url.replace("?", "").split('&');
    for (var mitem in canshuji) {
        if (canshuji[mitem].split('=')[0] == key) {
            return canshuji[mitem].split('=')[1];
        }
    }
    return null;
}

//创建弹窗
//mtitle-窗体标题
//murl-窗体加载网页地址
//mwidth-宽度例如:100
//mheight-高度例如:100
//mmodel-是否有遮罩层(true/false)
//propertys-对话框的其他属性设置，如：关闭事件{onClose:function(){alert('关闭');}}
var _dialogid = "commondialog";
var _dialogframeid = "commondialogFrame";
function CreateDilog(mtitle, murl, mwidth, mheight, mmodel, propertys) {
    //初始化
    initDialog();
    //打开窗口
    var defpro = {
        title: mtitle,
        width: mwidth,
        height: mheight,
        modal: mmodel,
        closed: false
    };
    var pro = $.extend({}, defpro, propertys);
    //构造dialog
    $("#" + _dialogid).dialog(pro);
    //赋值url
    $("#" + _dialogframeid).attr("src", murl);
}


var _dialogid1 = "commondialog1";
var _dialogframeid1 = "commondialogFrame1";
function CreateDilog1(mtitle, murl, mwidth, mheight, mmodel, propertys) {
    //初始化
    initDialog1();
    //打开窗口
    var defpro = {
        title: mtitle,
        width: mwidth,
        height: mheight,
        modal: mmodel,
        closed: false
    };
    var pro = $.extend({}, defpro, propertys);
    //构造dialog
    $("#" + _dialogid1).dialog(pro);
    //赋值url
    $("#" + _dialogframeid1).attr("src", murl);
}
//关闭
function CloseDilog() {
    $("#" + _dialogid).dialog("close");
}
function CloseDilog1() {
    $("#" + _dialogid1).dialog("close");
}
//初始化
function initDialog() {
    //解决flash报的脚本错误
    var fmdoc = document.getElementById(_dialogframeid);
    if (fmdoc && fmdoc.contentWindow
        && fmdoc.contentWindow.document
        && fmdoc.contentWindow.document.body) {
        fmdoc.contentWindow.document.body.innerHTML = "";
    }
    //清空
    $("#" + _dialogid).dialog("destroy");
    //创建
    var div = "<div id='" + _dialogid + "' style='width:0;height:0;overflow:hidden'>";
    div += "<iframe id='" + _dialogframeid + "' frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\"  style='width:100%;height:100%;border:none' scrolling='yes' src=''></iframe>";
    div += "</div>";
    $("body").append(div);
}
function initDialog1() {
    //解决flash报的脚本错误
    var fmdoc = document.getElementById(_dialogframeid1);
    if (fmdoc && fmdoc.contentWindow
        && fmdoc.contentWindow.document
        && fmdoc.contentWindow.document.body) {
        fmdoc.contentWindow.document.body.innerHTML = "";
    }
    //清空
    $("#" + _dialogid1).dialog("destroy");
    //创建
    var div = "<div id='" + _dialogid1 + "' style='width:0;height:0;overflow:hidden'>";
    div += "<iframe id='" + _dialogframeid1 + "' frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\"  style='width:100%;height:100%;border:none' scrolling='yes' src=''></iframe>";
    div += "</div>";
    $("body").append(div);
}




///页面打印功能
var PrintReady = false;
$(function () {
    //添加打印组件
    if (!document.getElementById("LODOP_OB")) {
        var obj = "<object  id=\"LODOP_OB\" classid=\"clsid:2105C259-1E0C-4534-8141-A753534CB4CA\" width=0 height=0>";
        obj += "<embed id=\"LODOP_EM\" type=\"application/x-print-lodop\" width=0 height=0></embed> ";
        obj += "</object>";
        if (document.body) {
            $(document.body).append($(obj));
        }
    }
    //加载js
    $.getScript("/Scripts/System/LodopFuncs.js").done(function () {
        PrintReady = true;
    }).fail(function (d) { PrintReady = false; });
});
//打印对象
//如果obj中的html对象包括了class=“printpage”，将以分页的形式打印
//opts打印设置{orient:1}-orient:1-纵向，2-横向
function Print(obj, opts) {

    //if (_jQyeryPrintLoaded == true) {
    //    $(obj).print({
    //        globalStyles: true,
    //        mediaPrint: false,
    //        stylesheet: null,
    //        noPrintSelector: ".no-print",
    //        iframe: true,
    //        append: null,
    //        prepend: null,
    //        manuallyCopyFormValues: true,
    //        deferred: $.Deferred(),
    //        timeout: 750,
    //        title: null,
    //        doctype: '<!doctype html>'
    //    });
    //}

    //return;

    if (PrintReady) {
       
        //打印组件
        var LODOP = getLodop(document.getElementById('LODOP_OB'), document.getElementById('LODOP_EM'));

        var pages = $(".printpage");
        //带有分页标记
        if (pages.length > 0) {
            for (var i = 0; i < pages.length; i++) {
                LODOP.NewPage();
                LODOP.ADD_PRINT_HTM("2%", "2%", "96%", "96%", $(pages[i]).prop('outerHTML'));
            }
        }
        //不带分页标记
        else {
            LODOP.ADD_PRINT_HTM("2%", "2%", "96%", "96%", $(obj).html());
        }
        if (opts) {
            //纸张
            var pageName = "A4"
            if (opts.pageName) {
                pageName = opts.pageName;
            }
            //横向打印
            if (opts.orient) {
                //横向打印
                LODOP.SET_PRINT_PAGESIZE(opts.orient, 0, 0, pageName);
                //默认横向预览
                if (opts.orient == 2) {
                    LODOP.SET_SHOW_MODE("LANDSCAPE_DEFROTATED", 1);
                }
            }
        }
        LODOP.PREVIEW();
    }
    else {
        MsgShow("打印组件尚未准备好，请稍候！", "info", 1000);
    }
}

//jQuery.print方式打印
_jQyeryPrintLoaded = false;
$(function () {
    /// <reference path="E:\Mywork\昆仑燃气\程序\KLRQ\Web\jQuery.print/jQuery.print.js" />
    //$.getScript("/jQuery.print/jQuery.print.js", function (response, status) {
    //    if (status == "success") {
    //        _jQyeryPrintLoaded = true;
    //    }
    //});
});
//带有ajax页面请求的按钮控制
//linkbutton 中属性 AjaxComplete="true"的按钮
function enableAjaxLinkbtn() {
    $("[AjaxComplete='true']").linkbutton("enable");
    $.messager.progress("close");
}
function disableAjaxLinkbtn() {
    $("[AjaxComplete='true']").linkbutton("disable");
    //加进度条
    $.messager.progress({
        title: '提示',
        msg: '正在处理，请稍候...'
    });
}


//皮肤管理功能
$(function () {
    refreshTheme();
});
//改变默认皮肤
var _currentTheme = "default";
function changeTheme(theme) {
    setCookie("theme", theme);
}
//刷新皮肤
function refreshTheme() {
    var cookieTheme = getCookie('theme');
    if (cookieTheme && cookieTheme != "" && _currentTheme != cookieTheme) {
        _currentTheme = cookieTheme;
        //~/easyui/themes/default/easyui.css
        $("link").each(function (index, obj) {
            var linkhref = $(this).attr("href");
            //easyui的皮肤
            if (linkhref.indexOf("easyui.css") > 0) {
                var newhref = "/easyui/themes/" + _currentTheme + "/easyui.css";
                $(this).attr("href", newhref);
            }
            //desktop皮肤
            if (linkhref.indexOf("desktop.css") > 0) {
                var newhref = "/Content/Theme/" + _currentTheme + "/desktop.css";
                $(this).attr("href", newhref);
            }
            //首页皮肤
            if (linkhref.toLowerCase().indexOf("homeindex.css") > 0) {
                var newhref = "/Content/Theme/" + _currentTheme + "/homeindex.css";
                $(this).attr("href", newhref);
            }
        });
    }
    this.setTimeout(refreshTheme, 500);
}
//设置cookie
function setCookie(name, value,expires,path) {
    var Days = 1000;
    var Path = "/";
    if (expires) {
        days = expires;
    }
    if (path && path != "") {
        Path = path;
    }
    var exp = new Date();
    exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
    document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString() + ";path=" + Path;
}
//读取cookie
function getCookie(name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg))
        return unescape(arr[2]);
    else
        return null;
}

//通用的查看审核记录（工作流审核记录查看的除外）
function viewUserAuditHistory(provider, objid, title) {
    var t = "审核记录";
    if (title && title != "") {
        t = title;
    }
    var url = "/AuditHistory/Display?provider=" + provider + "&objid=" + objid + "&rand=" + Math.random();
    CreateDilog(t, url, 700, 500, true, {
        maximizable: true,
        maximized: true
    });
}

//easyui默认属性
//验证控件的错误提示位置
 $.fn.validatebox.defaults.tipPosition = "bottom";
 $.fn.textbox.defaults.tipPosition = "bottom";
 $.fn.combobox.defaults.tipPosition = "bottom";
 $.fn.datebox.defaults.tipPosition = "bottom";
 $.fn.numberbox.defaults.tipPosition = "bottom";
 $.fn.numberspinner.defaults.tipPosition = "bottom";
 $.fn.timespinner.defaults.tipPosition = "bottom";
//datebox默认不可编辑
 $.fn.datebox.defaults.editable = false;
//下拉框默认的最大下拉值
 $.fn.combobox.defaults.panelMaxHeight = 120;
//datebox默认的值转换
 $.fn.datebox.defaults.parser = function (s) {
     s = s.replace(/-/g, "/");
     var t = Date.parse(s);
     if (!isNaN(t)) {
         return new Date(t);
     } else {
         return new Date();
     }
 }
//textbox默认的输入长度
 $.fn.textbox.defaults.validType = "length[0,25]";

//系统工具
 var SysTool = {
     //将字符串转为时间类型
     toDateTime: function (s) {
         s = s.replace(/-/g, "/");
         var t = Date.parse(s);
         return t;
     }
 };

//给textbox控件自动选择功能
 function setSelectPanel(targetid, options) {
     if (targetid == null || targetid == "") {
         return;
     }
     var defaults = {
         data: [],
         onselect: function (value) {
             $("#" + targetid).textbox("setText", value);
             $("#" + targetid).textbox("setValue", value);
         }
     };
     var options = $.extend({}, defaults, options);
     if (options.data.length < 1) {
         return;
     }

     var mouseover = false;
     var listid = "_autolist";
     var obj = $("#" + listid);
     $("#" + targetid).textbox("textbox").bind("focus click keyup", function () {
         //显示下拉内容
         if (obj.length == 0) {
             var html = "<div id='" + listid + "' style='display:block;border:1px solid rgb(149,184,231);background-color:white;overflow:auto;display:none;'>";
             for (var i = 0; i < options.data.length; i++) {
                 html += "<div style='cursor:pointer;padding:5px'>" + options.data[i] + "</div>";
             }
             html += "</div>";
             $("#" + targetid).parent().append(html);
             obj = $("#" + listid);
             //显示样式控制
             $(obj).css({
                 "position": "absolute",
                 "left": ($(this).offset().left - 1) + "px",
                 "top": ($(this).offset().top + $(this).height() + 9) + "px",
                 "width": ($(this).width() + 9) + "px",
                 "z-index": "10000"
             });
             if (options.height) {
                 $(obj).css("height", options.height + "px");
             }
            
             //显示
             if ($("#" + targetid).textbox("getText") == "") {
                 $(obj).show();
             }
             //鼠标在其上面
             $(obj).mouseover(function () {
                 mouseover = true;
             })
             //鼠标离开
                   .mouseout(function () {
                       mouseover = false;
                   });
             //选中数据
             $(obj).find("div").click(function () {
                 $(obj).hide();
                 mouseover = false;
                 //选择数据事件
                 var value = $(this).text();
                 if (options.onselect) {
                     options.onselect(value);
                 }
             })
             .mousemove(function () {
                 $(this).css("background-color", "rgb(234,242,255)");
             })
             .mouseout(function () {
                 $(this).css("background-color", "white");
             });
         }
         else {
             //显示
             if ($("#" + targetid).textbox("getText") == "") {
                 obj = $("#" + listid);
                 $(obj).css({
                     "position": "absolute",
                     "left": ($(this).offset().left - 1) + "px",
                     "top": ($(this).offset().top + $(this).height() + 9) + "px",
                     "width": ($(this).width() + 9) + "px",
                     "z-index": "10000"
                 });
                 $(obj).show();
             }
         }
     });
     $("#" + targetid).textbox("textbox").bind("blur", function () {
         if (mouseover == false) {
             $("#" + listid).hide();
         }
     });
 }