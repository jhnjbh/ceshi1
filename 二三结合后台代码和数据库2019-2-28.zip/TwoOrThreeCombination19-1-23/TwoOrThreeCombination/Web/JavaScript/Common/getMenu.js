﻿//获取当前网站的host
var host = window.location.host;
//获取当前菜单下的二级子菜单
function getMenu(data) {
    ////调整左侧菜单区域的大小
    //$("#leftPanel").attr("style", "height:" + (parent.document.body.clientHeight - 120) + "px;");
    //获取二级菜单面板数据
    if (data.length > 0) {
        //循环将面板数据添加到左侧面板
        for (var i = 0; i < data.length; i++) {
            $("#accordion").append("<div class=\"panel panel-info\" id=\"Panel_" + data[i].id + "\"><div class=\"panel-heading\"><h4 class=\"panel-title\"><img id=\"toggle" + data[i].id + "\" src='../Image/triangle_right16.png' style='margin-top:-5px;'>&nbsp;<a id=\"Text_" + data[i].id + "\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapse" + data[i].id + "\" onclick=\"addPanel('" + data[i].id + "')\">" + data[i].text + "</a></h4></div></div>");
        }
    }
    else {
        msgShow("获取菜单时出现数据异常", "no", 500);
    }
}
//获取二级子菜单下的其他菜单
function addPanel(id) {
    var data= {
            node: [
            { id: "123", text: "123", url: "HtmlPage2.html", icon: "false" },
                    { id: "234", text: "234", url: "HtmlPage2.html", icon: "false" },
                    { id: "345", text: "345", url: "HtmlPage2.html", icon: "false" },
                    { id: "456", text: "456", url: "HtmlPage2.html", icon: "false" }
            ]
    }
    //判断当前面板的子菜单是否已经存在
    var jstree = $("#jstree" + id);
    if (jstree.length == 0) {
        //如果不存在，则向当前面板追加子菜单
        $("#Panel_" + id).append("<div id=\"collapse" + id + "\" class=\"panel-collapse collapse\"><div id=\"jstree" + id + "\" style=\"overflow:auto;overflow-y:hidden;\"></div></div>");
        if (data.node.length > 0) {
            //给菜单树添加节点
            $('#jstree' + id).jstree({
                'core': {
                    data: data.node,
                    strings: {
                        'Loading ...': 'Please wait ...'
                    },
                    animation: 200,
                    multiple: true,
                    themes: {
                        dots: false,
                        "stripes": true
                    }
                }
            });
            //给菜单树添加节点点击事件
            $('#jstree' + id).on("activate_node.jstree", function (e, data) {
                if (!$("#li" + data.node.id).length) {
                    //追加一个标签页以及其内容
                    $("#myTab").append("<li id='Tap" + data.node.id + "' style='margin-top:2px;'><a href='#Content" + data.node.id + "' data-toggle='tab' id='li" + data.node.id + "'>" + data.node.text + "&nbsp;&nbsp;<img src='../Image/closeNoCircle.png' id='close" + data.node.id + "' style='display:inline;cursor:pointer;width:10px;' /></a></li>");
                    $("#myTabContent").append("<div class='tab-pane fade' id=\"Content" + data.node.id + "\"><iframe id=\"IF" + data.node.id + "\" style=\"border:none;width:100%;height:" + (parent.document.body.clientHeight - 200) + "px;\" src=\"" + data.node.original.url + "\"></iframe></div>");
                    //模拟点击事件，转到当前页面
                    $("#li" + data.node.id).click();
                    $("#close" + data.node.id).on("click", function () {
                        $("#Tap" + $(this).attr("id").substr(5)).remove();
                        $("#Content" + $(this).attr("id").substr(5)).remove();
                        if ($("#myTab li").length > 0) {
                            $("#myTab li :first").click();
                        }
                    });
                }
                else {
                    //如果标签页存在，则选中
                    $("#li" + data.node.id).click();
                }
            });
        }
        else {
            msgShow("获取子菜单时出现数据异常", "no", 500);
        }
    }
    $(".panel-collapse.collapse").each(function (index, element) {
        if (element.className.indexOf(" in") > 0) {
            $("#toggle" + (element.id).substring(8)).attr("src", "../Image/triangle_right16.png");
        }
        else if ((element.id).substring(8) == id) {
            $("#toggle" + (element.id).substring(8)).attr("src", "../Image/triangle_bottom16.png");
        }
        else {
            $("#toggle" + (element.id).substring(8)).attr("src", "../Image/triangle_right16.png");
        }
    });
}