﻿
//消息提示(非弹窗,自动消失)
//text:提示的文字
//type:消息类型-(成功:ok 错误:no 提示:info)
//time:消息停留时间-(1秒:1000)
//如:MsgShow("操作成功","ok",1000);
function msgShow(text, type, time, callback) {
    $("#mymsg").remove();
    var linshicolor = "";
    if (type == "ok") {
        linshicolor = "#7FE118";
    } else if (type == "no") {
        linshicolor = "#E65E5E";
    } else {
        linshicolor = "#70BFEA";
    }
    $("body").append('<div id="mymsg" style="background-color: ' + linshicolor + ';width: 300px;position: fixed;top: 35px;left: 50%;z-index:999999;color: white;padding: 15px 10px 15px 10px;font-weight: bold;text-align: center;margin-left: -150px;border-radius: 4px;display:none;">' + text + '</div>');
    $("#mymsg").slideDown("100", function () {
        setTimeout(function () {
            $("#mymsg").slideUp("slow", callback);
        }, time);
    });
}