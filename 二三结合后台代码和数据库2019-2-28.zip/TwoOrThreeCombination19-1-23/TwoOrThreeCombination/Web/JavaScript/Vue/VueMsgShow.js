﻿/*
 * 注：
 * 1、使用此js需要引用jquery
 * 2、使用此js需要引用vue.js
 * 3、使用此js需要引用样式表VueMsgShow.css
 */
//消息展示

var display = null;
function msgShow(text, type, time) {
    display.message = text;
    if (type == "ok") {
        display.styleMsgShow["background-color"] = display.colors[0];
    }
    else if (type == "no") {
        display.styleMsgShow["background-color"] = display.colors[1];
    }
    else {
        display.styleMsgShow["background-color"] = display.colors[2];
    }
    time = time == undefined ? 500 : time;
    display.dispalyOpera();
    setTimeout(function () {
        display.dispalyOpera();
    }, time);
}

//新建Vue对象
var div = document.createElement("div");
var transition = document.createElement("transition");
var p = document.createElement("p");

div.id = "msgShow";

div.setAttribute("style", "position:fixed;background-color:#7FE118;margin-left:40%;text-align:center;border-radius:3px;width:20%;z-index:999999;top: 35px;border:none;");

transition.setAttribute("name", "bounce");

p.setAttribute("v-if", "show");

div.appendChild(transition);
transition.appendChild(p);
p.innerText = "{{message}}";
window.onload = function () {
    document.body.appendChild(div);
    display = new Vue({
        el: '#msgShow',
        data: {
            colors: ["#7FE118", "#E65E5E", "#70BFEA"],
            message: "",
            styleMsgShow: {
                "position": "relative",
                "background-color": "#7FE118",
                "margin-left": "40%",
                "top": "5px",
                "text-align": "center",
                "border-radius": "3px",
                "width": "20%",
                "z-index": "999999"
            },
            show: false
        },
        methods: {
            dispalyOpera: function (event) {
                this.show = !this.show;
            }
        }
    });
}