﻿using DAL;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using TwoOrThreeCombination.DB;
using TwoOrThreeCombination.Model;

namespace TwoOrThreeCombination.Web.Page
{
    /// <summary>
    /// BenefitEvaluation 的摘要说明
    /// </summary>
    public class Calculation : IHttpHandler
    {
        DB.dal dal = new DB.dal();
        public void ProcessRequest(HttpContext context)
        {
            string type = context.Request["type"];
            string result = "error";
            if (type == "getData")
            {
                //获取项目数据

                //接收页面参数

                //将数据转换为jarray对象
                try
                {
                    result = getData();
                }
                catch (Exception ex)
                {
                }
                context.Response.ContentType = "text/plain";
                context.Response.Write(result);
            }
            else if (type == "add")
            {
                //获取项目数据

                //接收页面参数
                StreamReader stream = new StreamReader(context.Request.InputStream);
                string payload = stream.ReadToEnd();
                JObject data = null;
                //将数据转换为jarray对象
                try
                {
                    data = JObject.Parse(payload);
                    result = getCalculation(data);
                }
                catch (Exception ex)
                {
                    result = ex.ToString();
                }
                context.Response.ContentType = "text/plain";
                context.Response.Write(result);
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public string getData()
        {
            string result = "";
            DataSet ds_selDecisionFactor = new DataSet();
            string[] sqlStrKey = { };
            string[] sqlIntKey = { };
            int[] sqlIntValue = { };
            string[] sqlStrValue = { };
            ds_selDecisionFactor = dal.selAll(sqlStrKey, sqlStrValue, sqlIntValue, sqlIntKey, "sp_selBenefitEvaluation");
            if (ds_selDecisionFactor.Tables[0].Rows.Count > 0)
            {
                getDataTableColumnsName columns = new getDataTableColumnsName();
                BenefitEvaluation_Model base_data = new BenefitEvaluation_Model();
                result = columns.getSerilizerString(base_data, ds_selDecisionFactor.Tables[0]);
            }
            return result;
        }

        public string getCalculation(JObject data)
        {
            Dictionary<string, object> one = new Dictionary<string, object>()
            {
                { "annualOilProduction",double.Parse(data["One"].ToString())},    //年产油
                { "annualGasProduction",0},                                       //年产气
                { "totalWellNumber",1},                                           //总井数
                { "totalOilWellNumber",1},                                        //油井数
                { "developmentWellEngineeringInvestment",double.Parse(data["One_well"].ToString())},//开发井工程投资（万元） 
                { "groundEngineeringInvestment",double.Parse(data["One_ground"].ToString())},//地面工程投资（万元） 
                { "oldWellUsageInvestment",double.Parse(data["One_oldwell"].ToString())}, //老井利用 
            };
            Dictionary<string, object> two = new Dictionary<string, object>()
            {
                { "annualOilProduction",double.Parse(data["Two"].ToString())},    //年产油
                { "annualGasProduction",0},                                       //年产气
                { "totalWellNumber",1},                                           //总井数
                { "totalOilWellNumber",1},                                        //油井数
                { "developmentWellEngineeringInvestment",double.Parse(data["Two_well"].ToString())},//开发井工程投资（万元） 
                { "groundEngineeringInvestment",double.Parse(data["Two_ground"].ToString())},//地面工程投资（万元） 
                { "oldWellUsageInvestment",double.Parse(data["Two_oldwell"].ToString())}, //老井利用 
            };
            Dictionary<string, object> three = new Dictionary<string, object>()
            {
                { "annualOilProduction",double.Parse(data["Three"].ToString())},    //年产油
                { "annualGasProduction",0},                                       //年产气
                { "totalWellNumber",1},                                          //总井数
                { "totalOilWellNumber",1},                                       //油井数
                { "developmentWellEngineeringInvestment",double.Parse(data["Three_well"].ToString())},//开发井工程投资（万元） 
                { "groundEngineeringInvestment",double.Parse(data["Three_ground"].ToString())},//地面工程投资（万元） 
                { "oldWellUsageInvestment",double.Parse(data["Three_oldwell"].ToString())}, //老井利用 
            };
            Dictionary<string, object> four = new Dictionary<string, object>()
            {
                { "annualOilProduction",double.Parse(data["Four"].ToString())},    //年产油
                { "annualGasProduction",0},                                       //年产气
                { "totalWellNumber",1},                                          //总井数
                { "totalOilWellNumber",1},                                       //油井数
                { "developmentWellEngineeringInvestment",double.Parse(data["Four_well"].ToString())},//开发井工程投资（万元） 
                { "groundEngineeringInvestment",double.Parse(data["Four_ground"].ToString())},//地面工程投资（万元） 
                { "oldWellUsageInvestment",double.Parse(data["Four_oldwell"].ToString())}, //老井利用 
            };
            Dictionary<string, object> five = new Dictionary<string, object>()
            {
                { "annualOilProduction",double.Parse(data["Five"].ToString())},    //年产油
                //{ "annualOilProduction", 9.95},                                   //年产油
                { "annualGasProduction",0},                                       //年产气
                { "totalWellNumber",1},                                          //总井数
                { "totalOilWellNumber",1},                                       //油井数
                { "developmentWellEngineeringInvestment",double.Parse(data["Five_well"].ToString())},//开发井工程投资（万元） 
                { "groundEngineeringInvestment",double.Parse(data["Five_ground"].ToString())},//地面工程投资（万元） 
                { "oldWellUsageInvestment",double.Parse(data["Five_oldwell"].ToString())}, //老井利用 
            };
            Dictionary<string, object> six = new Dictionary<string, object>()
            {
                { "annualOilProduction",double.Parse(data["Six"].ToString())},    //年产油
                //{ "annualOilProduction", 0},                                      //年产油
                { "annualGasProduction",0},                                       //年产气
                { "totalWellNumber",1},                                           //总井数
                { "totalOilWellNumber",1},                                        //油井数
                { "developmentWellEngineeringInvestment",double.Parse(data["Six_well"].ToString())},//开发井工程投资（万元） 
                { "groundEngineeringInvestment",double.Parse(data["Six_ground"].ToString())},//地面工程投资（万元） 
                { "oldWellUsageInvestment",double.Parse(data["Six_oldwell"].ToString())}, //老井利用 
            };
            Dictionary<string, object> seven = new Dictionary<string, object>()
            {
                { "annualOilProduction",double.Parse(data["Seven"].ToString())},    //年产油
                //{ "annualOilProduction", 0},                                      //年产油
                { "annualGasProduction",0},                                       //年产气
                { "totalWellNumber",1},                                           //总井数
                { "totalOilWellNumber",1},                                        //油井数
                { "developmentWellEngineeringInvestment",double.Parse(data["Seven_well"].ToString())},//开发井工程投资（万元） 
                { "groundEngineeringInvestment",double.Parse(data["Seven_ground"].ToString())},//地面工程投资（万元） 
                { "oldWellUsageInvestment",double.Parse(data["Seven_oldwell"].ToString())}, //老井利用 
            };
            Dictionary<string, object> eight = new Dictionary<string, object>()
            {
                { "annualOilProduction",double.Parse(data["Eight"].ToString())},    //年产油
                { "annualGasProduction",0},                                       //年产气
                { "totalWellNumber",1},                                           //总井数
                { "totalOilWellNumber",1},                                        //油井数
                { "developmentWellEngineeringInvestment",double.Parse(data["Eight_well"].ToString())},//开发井工程投资（万元） 
                { "groundEngineeringInvestment",double.Parse(data["Eight_ground"].ToString())},//地面工程投资（万元） 
                { "oldWellUsageInvestment",double.Parse(data["Eight_oldwell"].ToString())}, //老井利用 
            };
            Dictionary<string, object> nine = new Dictionary<string, object>()
            {
                { "annualOilProduction",double.Parse(data["Nine"].ToString())},    //年产油
                { "annualGasProduction",0},                                       //年产气
                { "totalWellNumber",1},                                           //总井数
                { "totalOilWellNumber",1},                                        //油井数
                { "developmentWellEngineeringInvestment",double.Parse(data["Nine_well"].ToString())},//开发井工程投资（万元） 
                { "groundEngineeringInvestment",double.Parse(data["Nine_ground"].ToString())},//地面工程投资（万元） 
                { "oldWellUsageInvestment",double.Parse(data["Nine_oldwell"].ToString())}, //老井利用 
            };
            Dictionary<string, object> ten = new Dictionary<string, object>()
            {
                { "annualOilProduction",double.Parse(data["Ten"].ToString())},    //年产油
                { "annualGasProduction",0},                                       //年产气
                { "totalWellNumber",1},                                           //总井数
                { "totalOilWellNumber",1},                                        //油井数
                { "developmentWellEngineeringInvestment",double.Parse(data["Ten_well"].ToString())},//开发井工程投资（万元） 
                { "groundEngineeringInvestment",double.Parse(data["Ten_ground"].ToString())},//地面工程投资（万元） 
                { "oldWellUsageInvestment",double.Parse(data["Ten_oldwell"].ToString())}, //老井利用 
            };
            List<Dictionary<string, object>> li = new List<Dictionary<string, object>>()
            {
                one, two, three, four, five, six, seven, eight, nine, ten
            };
            Dictionary<string, object> paras = new Dictionary<string, object>()
            {
                { "organization", data["Organization"].ToString() },          //建设单位
                { "oilFieldName", data["Oil_fieldes"].ToString()  },          //油田名称
                { "developmentDistinct",data["DevelopmentDistinct"].ToString()},         //开发区块
                { "strategyCode",data["StrategyCode"].ToString()},                 //方案编号
                { "constructionStartYear",int.Parse(data["ConstructionStartYear"].ToString())},         //建设起始年份
                { "operationStartYear",int.Parse(data["OperationStartYear"].ToString())},            //运营期开始年
                { "costAdjustmentFactor",double.Parse(data["CostAdjustmentFactor"].ToString())},             //成本调整系数
                { "constructionYears", double.Parse(data["ConstructionYears"].ToString()) },              //建设期
                { "runYears", double.Parse(data["RunYears"].ToString()) },                       //运营期
                { "newCrudeOilCapacity", double.Parse(data["NewCrudeOilCapacity"].ToString()) },           //新建原油产能
                { "newGasCapacity", double.Parse(data["NewGasCapacity"].ToString())},                  //新建天然气产能
                { "crudeOilCommodityRate", double.Parse(data["CrudeOilCommodityRate"].ToString()) },      //原油商品率
                { "gasOilCommodityRate", double.Parse(data["GasOilCommodityRate"].ToString()) },        //天然气商品率
                { "crudeOilPrice", double.Parse(data["CrudeOilPrice"].ToString())},                  //原油价格
                { "productionDataList", li }             //生产经营数据表
            };

            httpNetworking client = new httpNetworking();
            //string dataassa = (new JavaScriptSerializer()).Serialize(paras);
            string postUrl = "http://10.76.174.42:8081/pec/api/tanhai/calculate";
            JObject jo = client.requestJsons(postUrl, "POST", paras);
            string respCode = "";
            if (jo == null)
            {
                Dictionary<string, int> dic = new Dictionary<string, int>();
                dic.Add("respCode", 999);
                respCode = JsonConvert.SerializeObject(dic);
            }
            else
            {
                respCode = jo.ToString();
                if (data["Proj_id"].ToString() == "")
                {
                    string[] sqlStrKey = { "@INTERNAL_INCOME_RATE", "@FINANCIAL_NET_PRESENT", "@PAYBACK_PERIOD", "@INPUT_OUTPUT_RATIO" };
                    string[] sqlIntKey = { "@PROJ_ID", "@PROG_ID" };
                    int[] sqlIntValue = { int.Parse(data["Proj_id"].ToString()), int.Parse(data["Prog_id"].ToString()) };
                    string[] sqlStrValue = {  jo["data"]["firr"].ToString(), jo["data"]["fnpv"].ToString(),
                                      jo["data"]["staticRecyclingPeriod"].ToString(),  jo["data"]["firr"].ToString()};
                    bool isTrue = dal.addOrAlterData(sqlStrKey, sqlStrValue, sqlIntValue, sqlIntKey, "sp_addBenefitEvaluation");
                }
            }
            return respCode;
        }
    }
}