﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;

namespace TwoOrThreeCombination.DB
{
    public class httpNetworking
    {
        public JObject requestJsons(string Url, string Method, Dictionary<string, object> parameters)
        {
            bool isHaveData = false;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
            //request.Timeout = 5000;
            //request.ReadWriteTimeout = 5000;
            System.Net.ServicePointManager.DefaultConnectionLimit = 50;
            request.Method = Method;
            request.KeepAlive = false;
            request.ContentType = "application/json";
            request.Accept = "application/json;charset=utf-8";

            string strContent = (new JavaScriptSerializer()).Serialize(parameters);



            using (StreamWriter dataStream = new StreamWriter(request.GetRequestStream()))
            {
                dataStream.Write(strContent);

                dataStream.Close();
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                string encoding = response.ContentEncoding;
                if (encoding == null || encoding.Length < 1)
                {
                    encoding = "UTF-8"; //默认编码  
                }
                StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding(encoding));
                string retString = reader.ReadToEnd();
                //解析josn
                JObject jo = JObject.Parse(retString);
                return jo;
            }
            catch (Exception e)
            {

            }

            return null;

        }
    }
}